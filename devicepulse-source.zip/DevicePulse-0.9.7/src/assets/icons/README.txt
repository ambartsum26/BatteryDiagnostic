DevicePulse 0.9.2 icon pack

Included icons:
- devicepulse-main: main app icon (Pulse Chip)
- cpu
- ram
- gpu
- storage
- battery

Each icon is provided as PNG and ICO on transparent background.
These assets were prepared to match the approved cyan/blue neon DevicePulse style.
