﻿# Run on Windows 11 x64 with .NET 10 SDK. No drivers are installed or changed.
[CmdletBinding()]
param([switch]$HardwareProbe, [switch]$UiSmoke, [switch]$SkipLibCdiDownload)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$project = Join-Path $PSScriptRoot 'src\BatteryDiagnostic.csproj'
$out = Join-Path $PSScriptRoot 'publish-win-x64'
if (!(Test-Path -LiteralPath $project)) { throw "Project not found: $project" }
$dotnet = Get-Command dotnet.exe -ErrorAction SilentlyContinue
if (!$dotnet) {
    $systemDotnet = Join-Path $env:ProgramFiles 'dotnet\dotnet.exe'
    if (Test-Path -LiteralPath $systemDotnet) { $dotnet = Get-Item -LiteralPath $systemDotnet }
}
if (!$dotnet) { throw '.NET 10 SDK is required. Run START-BATTERYDIAGNOSTIC.cmd to install it automatically.' }
Write-Host 'Building BatteryDiagnostic 0.7.8 (Windows x64)...'
& dotnet publish $project -c Release -r win-x64 --self-contained true `
    '-p:PublishSingleFile=true' '-p:IncludeNativeLibrariesForSelfExtract=true' -o $out
if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed with code $LASTEXITCODE" }
$exe = Join-Path $out 'BatteryDiagnostic.exe'
if (!(Test-Path -LiteralPath $exe)) { throw 'Published EXE not found' }
# libcdi is NOT in the source ZIP: fetch the verified upstream NWinfo x64 DLL.
# Only the read-only libcdi getters are called by BatteryDiagnostic.
$libcdi = Join-Path $out 'libcdi.dll'
if (!$SkipLibCdiDownload -and !(Test-Path -LiteralPath $libcdi)) {
    $url = 'https://github.com/a1ive/nwinfo/releases/download/v1.6.6/NWinfo.zip'
    $expected = '52006A9280B53449375FD8D7211A2A8DEF7E287F93028BB469660CE877BD4A2E'
    $temp = Join-Path ([IO.Path]::GetTempPath()) ('battery-libcdi-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $temp | Out-Null
    try {
        $archive = Join-Path $temp 'NWinfo.zip'
        Write-Host 'Downloading official NWinfo v1.6.6 to install libcdi.dll ...'
        Invoke-WebRequest -Uri $url -OutFile $archive -UseBasicParsing -ErrorAction Stop
        $sha = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash
        if ($sha -ne $expected) { throw 'NWinfo.zip SHA256 mismatch: aborting DLL installation' }
        Expand-Archive -LiteralPath $archive -DestinationPath (Join-Path $temp 'unzipped') -ErrorAction Stop
        $items = @(Get-ChildItem -LiteralPath (Join-Path $temp 'unzipped') -Recurse -File | Where-Object { $_.Name -ieq 'libcdi.dll' })
        $x64 = @($items | Where-Object {
            $s = [IO.File]::OpenRead($_.FullName)
            try {
                $br = New-Object IO.BinaryReader($s)
                if ($br.ReadUInt16() -ne 0x5A4D) { return $false }
                [void]$s.Seek(0x3C, [IO.SeekOrigin]::Begin)
                $pe = $br.ReadInt32()
                if ($pe -lt 64 -or $pe -gt $s.Length - 24) { return $false }
                [void]$s.Seek($pe, [IO.SeekOrigin]::Begin)
                if ($br.ReadUInt32() -ne 0x00004550) { return $false }
                return ($br.ReadUInt16() -eq 0x8664)
            }
            finally { $s.Dispose() }
        })
        if ($x64.Count -ne 1) { throw "Expected exactly one PE x64 libcdi.dll; found $($x64.Count) among $($items.Count) DLL(s)" }
        Copy-Item -LiteralPath $x64[0].FullName -Destination $libcdi -Force
        Write-Host 'Verified libcdi.dll copied to publish-win-x64.'
    }
    catch {
        Write-Warning ('libcdi installation failed: ' + $_.Exception.Message)
        Write-Warning 'BatteryDiagnostic can still run, but CrystalDiskInfo backend will remain disabled.'
        Write-Warning 'Download NWinfo.zip from https://github.com/a1ive/nwinfo/releases/tag/v1.6.6 then copy its x64 libcdi.dll beside BatteryDiagnostic.exe.'
    }
    finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }
}
if (Test-Path -LiteralPath $libcdi) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'src\ThirdParty\libcdi\LICENSE.txt') -Destination (Join-Path $out 'libcdi-LICENSE.txt') -Force
}
Write-Host ('libcdi status: ' + $(if (Test-Path -LiteralPath $libcdi) { 'Installed' } else { 'Not installed' }))
Push-Location $out
try {
    Remove-Item -LiteralPath (Join-Path $out 'self-test.txt') -ErrorAction SilentlyContinue
    Write-Host 'Running built-in tests...'
    $run = Start-Process -FilePath $exe -ArgumentList '--self-test' -WorkingDirectory $out -Wait -PassThru
    if ($run.ExitCode -ne 0) { throw "self-test failed (exit code $($run.ExitCode))" }
    if (!(Test-Path -LiteralPath (Join-Path $out 'self-test.txt'))) {
        throw 'self-test.txt missing; see error.txt for details'
    }
    Get-Content -LiteralPath (Join-Path $out 'self-test.txt')
    if ($HardwareProbe) {
        Write-Host 'Reading physical storage and performance sensors (read-only)...'
        Remove-Item -LiteralPath (Join-Path $out 'performance-probe.json') -ErrorAction SilentlyContinue
        $run = Start-Process -FilePath $exe -ArgumentList '--performance-probe' -WorkingDirectory $out -Wait -PassThru
        if ($run.ExitCode -ne 0) { throw "performance-probe failed (exit code $($run.ExitCode))" }
        if (!(Test-Path -LiteralPath (Join-Path $out 'performance-probe.json'))) {
            throw 'performance-probe.json missing; see error.txt'
        }
        Write-Host 'Hardware report:' (Join-Path $out 'performance-probe.json')
    }
    if ($UiSmoke) {
        Write-Host 'Running interactive WinForms UI tests...'
        $run = Start-Process -FilePath $exe -ArgumentList '--ui-smoke' -WorkingDirectory $out -Wait -PassThru
        if ($run.ExitCode -ne 0) { throw "ui-smoke failed (exit code $($run.ExitCode))" }
        if (!(Test-Path -LiteralPath (Join-Path $out 'ui-smoke-result.txt'))) {
            throw 'ui-smoke-result.txt missing; see error.txt'
        }
        Get-Content -LiteralPath (Join-Path $out 'ui-smoke-result.txt')
    }
}
finally { Pop-Location }
Write-Host 'Build + requested tests completed. EXE:' $exe
