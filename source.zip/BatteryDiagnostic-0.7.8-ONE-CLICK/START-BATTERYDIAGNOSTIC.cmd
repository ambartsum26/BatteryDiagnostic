@echo off
setlocal
cd /d "%~dp0"
title BatteryDiagnostic 0.7.8 - Automatic Installation
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ONE-CLICK.ps1"
if errorlevel 1 (
  echo.
  echo Installation did not finish. See BUILD-LOG.txt or BUILD-ERROR.txt in this folder.
  pause
)
endlocal
