﻿# BatteryDiagnostic one-click local Windows build/installation.
# No command-line typing is needed: double-click START-BATTERYDIAGNOSTIC.cmd.
# Requires the .NET 10 SDK, installed earlier on this machine.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$buildScript = Join-Path $root 'BUILD-AND-TEST.ps1'
$buildLog = Join-Path $root 'BUILD-LOG.txt'
$errorLog = Join-Path $root 'BUILD-ERROR.txt'

# Elevation is required for physical SMART access, as documented by libcdi.
# We perform compilation and sensor sampling in the same elevated process.
try {
    $me = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($me)
    $isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        $argsLine = '-NoProfile -ExecutionPolicy Bypass -File "' + $MyInvocation.MyCommand.Path + '"'
        $child = Start-Process -FilePath 'powershell.exe' -ArgumentList $argsLine -Verb RunAs -PassThru
        exit 0
    }
} catch {
    Write-Host ('Cannot obtain administrator privileges: ' + $_.Exception.Message)
    exit 1
}

$transcribing = $false
try {
    if (!(Test-Path -LiteralPath $buildScript)) { throw 'BUILD-AND-TEST.ps1 was not found in the extracted folder.' }
    Remove-Item -LiteralPath $errorLog -Force -ErrorAction SilentlyContinue
    Start-Transcript -LiteralPath $buildLog -Force -ErrorAction Stop | Out-Null
    $transcribing = $true
    Write-Host 'BatteryDiagnostic 0.7.8: automatic build + tests + first hardware sample.'
    Write-Host 'Do not close this window while the build is running.'
    Write-Host ''

    # This computer can have multiple Windows users, and the SDK may have been
    # installed in another user's account. Find a real .NET 10 SDK, not just
    # a dotnet runtime or an unrelated dotnet.exe on PATH.
    function Find-Dotnet10 {
        $candidates = New-Object 'System.Collections.Generic.List[string]'
        $command = Get-Command 'dotnet.exe' -ErrorAction SilentlyContinue
        if ($command -and $command.Source) { [void]$candidates.Add($command.Source) }
        if ($env:ProgramFiles) { [void]$candidates.Add((Join-Path $env:ProgramFiles 'dotnet\dotnet.exe')) }
        if ($env:LOCALAPPDATA) { [void]$candidates.Add((Join-Path $env:LOCALAPPDATA 'Microsoft\dotnet\dotnet.exe')) }
        if ($env:USERPROFILE) { [void]$candidates.Add((Join-Path $env:USERPROFILE '.dotnet\dotnet.exe')) }
        foreach ($candidate in ($candidates | Select-Object -Unique)) {
            if (!(Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
            try {
                $versions = @(& $candidate --list-sdks 2>$null)
                if ($LASTEXITCODE -eq 0 -and ($versions | Where-Object { $_ -match '^\s*10\.\d+\.' })) {
                    return $candidate
                }
            } catch { }
        }
        return $null
    }

    $sdk = Find-Dotnet10
    if (!$sdk) {
        Add-Type -AssemblyName System.Windows.Forms
        $answer = [System.Windows.Forms.MessageBox]::Show(
            'Для сборки BatteryDiagnostic.exe на этом компьютере не найден .NET 10 SDK.' + "`r`n`r`n" +
            'Разрешить однократную установку официального .NET 10 SDK от Microsoft? Дальше сборка и запуск выполнятся автоматически. Для установки нужен интернет.',
            'BatteryDiagnostic — требуется .NET 10 SDK',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
            throw 'Installation of .NET 10 SDK was declined. No program was installed.'
        }
        Write-Host 'Installing official .NET 10 SDK (Windows x64)...'
        $winget = Get-Command 'winget.exe' -ErrorAction SilentlyContinue
        if ($winget) {
            try {
                & $winget.Source install --id Microsoft.DotNet.SDK.10 --exact --source winget --silent --scope machine --accept-package-agreements --accept-source-agreements
                if ($LASTEXITCODE -ne 0) { Write-Warning ('WinGet exit code: ' + $LASTEXITCODE) }
            } catch { Write-Warning ('WinGet installation unavailable: ' + $_.Exception.Message) }
        }
        $sdk = Find-Dotnet10
        if (!$sdk) {
            # Official .NET release metadata gives both the installer URL and
            # SHA-512. Never download or execute an unsigned SDK installer.
            Write-Host 'Trying official Microsoft installer from .NET release metadata...'
            $metadataUrl = 'https://dotnetcli.blob.core.windows.net/dotnet/release-metadata/10.0/releases.json'
            $metadata = Invoke-RestMethod -Uri $metadataUrl -TimeoutSec 45 -ErrorAction Stop
            $selection = $null
            foreach ($release in @($metadata.releases)) {
                if (!$release.sdk) { continue }
                foreach ($entry in @($release.sdk.files)) {
                    if ($entry.rid -eq 'win-x64' -and $entry.name -like '*.exe' -and
                        $entry.url -match '^https://(builds\.dotnet\.microsoft\.com|dotnetcli\.azureedge\.net)/' -and
                        $entry.hash -match '^[0-9a-fA-F]{128}$') {
                        $selection = $entry
                        break
                    }
                }
                if ($selection) { break }
            }
            if (!$selection) { throw 'An authenticated .NET 10 x64 installer was not found in official Microsoft release metadata.' }
            $temp = Join-Path ([IO.Path]::GetTempPath()) ('battery-dotnet-' + [Guid]::NewGuid().ToString('N'))
            New-Item -Path $temp -ItemType Directory -ErrorAction Stop | Out-Null
            try {
                $setup = Join-Path $temp 'dotnet-sdk-10-win-x64.exe'
                Invoke-WebRequest -Uri $selection.url -OutFile $setup -UseBasicParsing -ErrorAction Stop
                $actual = (Get-FileHash -LiteralPath $setup -Algorithm SHA512).Hash
                if ($actual -ine $selection.hash) { throw 'SDK SHA-512 verification failed. Nothing will be installed.' }
                $signature = Get-AuthenticodeSignature -LiteralPath $setup
                if ($signature.Status -ne 'Valid' -or !$signature.SignerCertificate -or
                    $signature.SignerCertificate.Subject -notmatch 'Microsoft') {
                    throw 'SDK executable does not have a trusted Microsoft digital signature.'
                }
                $install = Start-Process -FilePath $setup -ArgumentList '/install /quiet /norestart' -Wait -PassThru
                if ($install.ExitCode -notin @(0,3010)) { throw ('SDK installer failed: ' + $install.ExitCode) }
                if ($install.ExitCode -eq 3010) { Write-Warning 'A Windows reboot may be required to complete SDK installation.' }
            } finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }
            $sdk = Find-Dotnet10
        }
        if (!$sdk) { throw 'Could not detect .NET 10 SDK after installation. Restart Windows and try again.' }
    }
    # Make the discovered machine-wide dotnet.exe visible to the child build
    # PowerShell. The EXE created below is self-contained and needs no SDK.
    $sdkDirectory = Split-Path -Parent $sdk
    $env:PATH = $sdkDirectory + ';' + $env:PATH
    Write-Host ('Using .NET 10 SDK: ' + $sdk)

    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $buildScript
    if ($LASTEXITCODE -ne 0) { throw ('Windows build or tests failed. Exit code: ' + $LASTEXITCODE) }

    $out = Join-Path $root 'publish-win-x64'
    $exe = Join-Path $out 'BatteryDiagnostic.exe'
    $dll = Join-Path $out 'libcdi.dll'
    if (!(Test-Path -LiteralPath $exe)) { throw 'The compiled BatteryDiagnostic.exe was not found.' }
    if (!(Test-Path -LiteralPath $dll)) {
        Write-Warning 'Optional libcdi.dll is unavailable. BatteryDiagnostic will use its other SMART sources.'
    }
    if (!(Test-Path -LiteralPath (Join-Path $out 'self-test.txt'))) { throw 'Automated tests did not produce self-test.txt.' }

    # PawnIO 2.2.0 is a separate, persistent Windows kernel driver.
    # Never bundle/execute unknown driver binaries; only the official release
    # identified by SHA-256 and trusted Authenticode is accepted.
    # Installation is performed ONCE, explicitly accepted by the user.
    # This preflight calls the application's own read-only driver verification.
    function Get-PawnIOStatus {
        $resultPath = Join-Path $out 'pawnio-status.json'
        Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
        $process = Start-Process -FilePath $exe -ArgumentList '--pawnio-status' -WorkingDirectory $out -Wait -PassThru
        if ($process.ExitCode -ne 0 -or !(Test-Path -LiteralPath $resultPath)) {
            throw 'PawnIO preflight failed; cannot safely decide whether to install the driver.'
        }
        return (Get-Content -LiteralPath $resultPath -Raw -Encoding UTF8 | ConvertFrom-Json)
    }

    try {
        $pawn = Get-PawnIOStatus
        Write-Host ('PawnIO before installation: ' + $pawn.DriverState + '; ' + $pawn.DriverDiagnostic)
        if ($pawn.ProcessorState -eq 'Ready' -and $pawn.DriverState -ne 'Ready') {
            Add-Type -AssemblyName System.Windows.Forms
            $message = 'Для самостоятельного чтения температуры процессора необходимо один раз установить официальный подписанный драйвер PawnIO 2.2.0.' + "`r`n`r`n" +
                'Он будет установлен в Windows и останется после закрытия BatteryDiagnostic. Понадобятся права администратора; иногда требуется перезагрузка.' + "`r`n`r`n" +
                'Установить драйвер сейчас? При отказе программа продолжит работать без этого источника температуры.'
            $answer = [System.Windows.Forms.MessageBox]::Show($message,'BatteryDiagnostic — датчик CPU',
                [System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
            if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) {
                $url = 'https://github.com/namazso/PawnIO.Setup/releases/download/2.2.0/PawnIO_setup.exe'
                # Pinned official PawnIO.Setup 2.2.0 installer hash (winget/Chocolatey manifest).
                $shaExpected = '1F519A22E47187F70A1379A48CA604981C4FCF694F4E65B734AAA74A9FBA3032'
                $tempDir = Join-Path ([IO.Path]::GetTempPath()) ('battery-pawnio-' + [Guid]::NewGuid().ToString('N'))
                New-Item -Path $tempDir -ItemType Directory -ErrorAction Stop | Out-Null
                try {
                    $setup = Join-Path $tempDir 'PawnIO_setup.exe'
                    Write-Host 'Downloading official signed PawnIO 2.2.0 installer...'
                    Invoke-WebRequest -Uri $url -OutFile $setup -UseBasicParsing -ErrorAction Stop
                    $actual = (Get-FileHash -LiteralPath $setup -Algorithm SHA256).Hash
                    if ($actual -ine $shaExpected) {
                        throw 'Official PawnIO 2.2.0 installer SHA-256 mismatch. Installation cancelled.'
                    }
                    $signature = Get-AuthenticodeSignature -LiteralPath $setup
                    if ($signature.Status -ne 'Valid' -or !$signature.SignerCertificate -or
                        $signature.SignerCertificate.Subject -notmatch 'namazso') {
                        throw 'PawnIO installer has no valid trusted publisher signature (namazso). Installation cancelled.'
                    }
                    Write-Host 'Installer hash and digital signature verified. Installing signed PawnIO driver...'
                    $install = Start-Process -FilePath $setup -ArgumentList '-install -silent' -Wait -PassThru
                    # 3010 = ERROR_SUCCESS_REBOOT_REQUIRED, officially documented by PawnIO 2.2.0.
                    if ($install.ExitCode -eq 3010) {
                        Write-Warning 'PawnIO was installed but Windows requires a reboot for the driver to work.'
                        [void][System.Windows.Forms.MessageBox]::Show(
                            'PawnIO установлен. Перезагрузи Windows, чтобы заработало чтение температуры CPU.',
                            'BatteryDiagnostic — нужна перезагрузка','OK','Information')
                    } elseif ($install.ExitCode -ne 0) {
                        throw ('Official PawnIO installer failed: exit code ' + $install.ExitCode)
                    }
                    $pawn = Get-PawnIOStatus
                    Write-Host ('PawnIO after installation: ' + $pawn.DriverState + '; ' + $pawn.DriverDiagnostic)
                    if ($pawn.DriverState -ne 'Ready') {
                        Write-Warning 'The driver is not yet verified. CPU DTS will remain unavailable until the problem is resolved or Windows is restarted.'
                    }
                }
                finally { Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue }
            } else {
                Write-Host 'PawnIO installation declined; other sensor providers remain available.'
            }
        } elseif ($pawn.ProcessorState -ne 'Ready') {
            Write-Host ('Intel DTS/PawnIO is not applicable: ' + $pawn.ProcessorDiagnostic)
        } else {
            Write-Host 'Official PawnIO already verified. No reinstall needed.'
        }
    }
    catch {
        # Driver installer failure must not block BatteryDiagnostic itself.
        Write-Warning ('PawnIO setup skipped/failed: ' + $_.Exception.Message)
    }

    # The app auto-enables PawnIO readings if official installed driver is verified.
    $probe = Join-Path $out 'performance-probe.json'
    Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
    $run = Start-Process -FilePath $exe -ArgumentList '--performance-probe' -WorkingDirectory $out -Wait -PassThru
    if ($run.ExitCode -ne 0) { throw ('Hardware probe failed: ' + $run.ExitCode) }
    if (!(Test-Path -LiteralPath $probe)) { throw 'performance-probe.json was not created.' }
    Write-Host ('Hardware report: ' + $probe)

    $desktop = [Environment]::GetFolderPath('Desktop')
    if (![string]::IsNullOrWhiteSpace($desktop) -and (Test-Path -LiteralPath $desktop)) {
        try {
            $shell = New-Object -ComObject WScript.Shell
            $shortcut = $shell.CreateShortcut((Join-Path $desktop 'BatteryDiagnostic 0.7.8.lnk'))
            $shortcut.TargetPath = $exe
            $shortcut.WorkingDirectory = $out
            $shortcut.IconLocation = ($exe + ',0')
            $shortcut.Description = 'BatteryDiagnostic 0.7.8 SMART and hardware diagnosis'
            $shortcut.Save()
            Write-Host ('Desktop shortcut created: ' + $desktop)
        } catch { Write-Warning ('Shortcut could not be created: ' + $_.Exception.Message) }
    }

    Write-Host 'The app is built. Starting BatteryDiagnostic...'
    Start-Process -FilePath $exe -WorkingDirectory $out -ErrorAction Stop
    Write-Host 'Done. To launch it later, use the desktop shortcut or publish-win-x64\BatteryDiagnostic.exe.'
}
catch {
    $msg = 'Automatic installation failed: ' + $_.Exception.Message
    $msg | Out-File -LiteralPath $errorLog -Encoding UTF8 -Force
    Write-Host $msg -ForegroundColor Red
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        [void][System.Windows.Forms.MessageBox]::Show(
            ($msg + "`r`n`r`nPlease attach BUILD-LOG.txt and BUILD-ERROR.txt from the unpacked folder."),
            'BatteryDiagnostic 0.7.8', 'OK', 'Error')
    } catch { }
    exit 1
}
finally {
    if ($transcribing) { try { Stop-Transcript | Out-Null } catch { } }
}
