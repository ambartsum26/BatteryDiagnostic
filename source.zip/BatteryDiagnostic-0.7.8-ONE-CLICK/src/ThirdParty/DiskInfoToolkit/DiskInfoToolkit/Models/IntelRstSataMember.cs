﻿/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2026 Florian K.
 */

using DiskInfoToolkit.Devices;

namespace DiskInfoToolkit.Models
{
    internal class IntelRstSataMember
    {
        public StorageDevice AggregateVolume { get; set; }

        public List<StorageDevice> Volumes { get; set; }
    }
}
