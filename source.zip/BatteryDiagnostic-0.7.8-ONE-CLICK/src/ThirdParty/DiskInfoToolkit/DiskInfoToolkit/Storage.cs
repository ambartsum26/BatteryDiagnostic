﻿/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2026 Florian K.
 */

using DiskInfoToolkit.Constants;
using DiskInfoToolkit.Core;
using DiskInfoToolkit.Devices;
using DiskInfoToolkit.Localization;
using DiskInfoToolkit.Monitoring;
using DiskInfoToolkit.Native;
using DiskInfoToolkit.Partitions;
using DiskInfoToolkit.Probes;
using DiskInfoToolkit.Smart;
using DiskInfoToolkit.StorageSpaces;
using DiskInfoToolkit.Utilities;
using Microsoft.Win32.SafeHandles;
using System.Globalization;
using System.Reflection;
using System.Resources;
using OS = BlackSharp.Core.Platform.OperatingSystem;

namespace DiskInfoToolkit
{
    /// <summary>
    /// This class provides static methods for storage device enumeration, monitoring and management.
    /// </summary>
    public static class Storage
    {
        #region Events

        /// <summary>
        /// Occurs when the set of available storage devices changes.
        /// </summary>
        /// <remarks>Subscribe to this event to be notified when storage devices are added or removed.<br/>
        /// The event provides information about the change through the <see cref="StorageDevicesChangedEventArgs"/> parameter.</remarks>
        public static event EventHandler<StorageDevicesChangedEventArgs> DevicesChanged
        {
            add
            {
                if (value == null)
                {
                    return;
                }

                lock (SyncRoot)
                {
                    _devicesChanged += value;
                }

                EnsureMonitoringStarted();
            }
            remove
            {
                if (value == null)
                {
                    return;
                }

                lock (SyncRoot)
                {
                    _devicesChanged -= value;
                }

                StopMonitoringIfUnused();
            }
        }

        #endregion

        #region Fields

        private const int MonitoringThreadStopTimeoutMilliseconds = 5000;

        private static readonly object SyncRoot = new object();

        private static readonly object ScanRoot = new object();

        private static readonly AutoResetEvent RescanSignal = new AutoResetEvent(false);

        private static readonly AutoResetEvent PartitionRefreshScheduleSignal = new AutoResetEvent(false);

        private static readonly ManualResetEvent MonitoringStopSignal = new ManualResetEvent(false);

        private static Thread _messageLoopThread;

        private static Thread _rescanThread;

        private static Thread _mediaWatchThread;

        private static bool _monitoringStarted;

        private static bool _monitoringStopping;

        private static bool _explicitMonitoringStarted;

        private static bool _excludeUsbDevices;

        private static TimeSpan _mediaWatchLoopDelay = TimeSpan.FromSeconds(1);

        private static TimeSpan _partitionRefreshInterval = TimeSpan.FromMinutes(5);

        private static CultureInfo _resourceCulture = CultureInfo.InvariantCulture;

        private static ResourceManager _resourceManager;

        private static string _resourceBaseName;

        private static List<StorageDevice> _currentDisks = new List<StorageDevice>();

        private static List<StorageDevice> _mediaWatchDevices = new List<StorageDevice>();

        private static Dictionary<string, bool?> _removableMediaStates = new Dictionary<string, bool?>(StringComparer.OrdinalIgnoreCase);

        private static EventHandler<StorageDevicesChangedEventArgs> _devicesChanged;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the maximum number of consecutive refresh failures allowed before fully reprobing the device.
        /// </summary>
        /// <remarks>The default value is 3.</remarks>
        public static int MaxConsecutiveRefreshFailureCount { get; set; } = 3;

        /// <summary>
        /// Gets or sets whether USB storage devices are excluded from detection, refreshes and monitoring.
        /// The default is false. A change during monitoring takes effect with the next scan;
        /// a scan already in progress finishes with its previous setting.
        /// </summary>
        /// <remarks>When enabled, drive-letter, free-space mapping, the Storage Spaces physical-drive
        /// fallback and mounted-volume usage scans are skipped because they can open USB volumes or
        /// disks before their USB connection is known.</remarks>
        public static bool ExcludeUsbDevices
        {
            get
            {
                lock (SyncRoot)
                {
                    return _excludeUsbDevices;
                }
            }
            set
            {
                lock (SyncRoot)
                {
                    if (_excludeUsbDevices == value)
                    {
                        return;
                    }

                    _excludeUsbDevices = value;

                    if (_monitoringStarted && !_monitoringStopping)
                    {
                        RescanSignal.Set();
                    }
                }
            }
        }

        /// <summary>
        /// Gets or sets the delay between removable-media polling cycles.<br/>
        /// Default is 1 second.
        /// </summary>
        /// <remarks>Setting a very low value may increase CPU usage, while setting a very high value may cause slower reaction to media changes.</remarks>
        public static TimeSpan MediaWatchLoopDelay
        {
            get
            {
                lock (SyncRoot)
                {
                    return _mediaWatchLoopDelay;
                }
            }
            set
            {
                if (value <= TimeSpan.Zero)
                {
                    throw new ArgumentOutOfRangeException(nameof(value));
                }

                lock (SyncRoot)
                {
                    _mediaWatchLoopDelay = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets how often monitored disks have their partitions checked independently of SMART refreshes.
        /// Zero disables the periodic check; device notifications and explicit refreshes still work.
        /// </summary>
        /// <remarks>The default interval is five minutes.</remarks>
        public static TimeSpan PartitionRefreshInterval
        {
            get
            {
                lock (SyncRoot)
                {
                    return _partitionRefreshInterval;
                }
            }
            set
            {
                if (value < TimeSpan.Zero
                 || (value > TimeSpan.Zero && value < TimeSpan.FromMilliseconds(1))
                 || value.TotalMilliseconds > int.MaxValue)
                {
                    throw new ArgumentOutOfRangeException(nameof(value));
                }

                lock (SyncRoot)
                {
                    _partitionRefreshInterval = value;
                }

                PartitionRefreshScheduleSignal.Set();
            }
        }

        /// <summary>
        /// Gets or sets the culture used to localize assembly resources.
        /// </summary>
        public static CultureInfo ResourceCulture
        {
            get
            {
                lock (SyncRoot)
                {
                    return _resourceCulture;
                }
            }
            set
            {
                lock (SyncRoot)
                {
                    _resourceCulture = value ?? CultureInfo.InvariantCulture;
                }
            }
        }

        /// <summary>
        /// Gets a snapshot of the currently cached storage devices.
        /// </summary>
        public static List<StorageDevice> CurrentDisks
        {
            get
            {
                lock (SyncRoot)
                {
                    return StorageDeviceCloneHelper.CloneList(_currentDisks);
                }
            }
        }

        #endregion

        #region Public

        /// <summary>
        /// Gets the list of currently visible storage devices.
        /// </summary>
        /// <returns>A list of <see cref="StorageDevice"/> objects representing the currently visible storage devices.</returns>
        public static List<StorageDevice> GetDisks()
        {
            EnumerateStorageState(ExcludeUsbDevices, out var visibleDisks, out var mediaWatchDevices, out var mediaStates);
            return visibleDisks;
        }

        /// <summary>
        /// Reads concrete Microsoft Storage Spaces pools, their spaces and member references.
        /// Mounted-volume usage is read from the spaces' virtual disk interfaces.
        /// </summary>
        /// <param name="disks">Existing disk objects to use for member references.</param>
        /// <returns>The non-primordial pools reported by Spaceport, or an empty list elsewhere.</returns>
        /// <remarks>When <see cref="ExcludeUsbDevices"/> is enabled, USB member references and mounted-volume usage are omitted.</remarks>
        public static List<StoragePool> GetStoragePools(IReadOnlyList<StorageDevice> disks)
        {
            if (disks == null)
            {
                throw new ArgumentNullException(nameof(disks));
            }

            bool excludeUsbDevices = ExcludeUsbDevices;

            IReadOnlyList<StorageDevice> visibleDisks = excludeUsbDevices
                ? disks.Where(disk => !UsbStorageDeviceIdentifier.IsUsbDevice(disk)).ToList()
                : disks;

            var ioControl = OS.IsWindows() ? StorageIoControlFactory.Create() : null;
            var pools = WindowsStorageSpacesPoolReader.Enumerate(visibleDisks, ioControl);

            if (ioControl != null && !excludeUsbDevices)
            {
                // Resolve each space's current virtual disk number and volumes independently
                // of the caller's disk snapshot, which may be empty or out of date.
                WindowsStorageSpaceVolumeReader.Populate(pools, ioControl);
            }

            return pools;
        }

        /// <summary>
        /// Reads the complete extent table of one Storage Spaces space on demand and
        /// reports its distinct physical disks. Existing disk objects are reused.
        /// </summary>
        /// <param name="pool">The pool containing the space and its already detected members.</param>
        /// <param name="space">The space whose extents are requested.</param>
        /// <param name="extentInfo">The complete extent snapshot on success, otherwise null.</param>
        /// <param name="maximumResponseBytes">The largest Spaceport response to allocate in bytes. Default is 128 MB.</param>
        /// <returns>Whether a complete, validated extent response was read.</returns>
        public static bool TryGetStorageSpaceExtentDisks(StoragePool pool, StorageSpace space,
            out StorageSpaceExtentInfo extentInfo, int maximumResponseBytes = 128 * 1000 * 1000)
        {
            if (pool == null)
            {
                throw new ArgumentNullException(nameof(pool));
            }

            if (space == null)
            {
                throw new ArgumentNullException(nameof(space));
            }

            if (space.PoolID != pool.ID)
            {
                throw new ArgumentException("The storage space does not belong to this pool.", nameof(space));
            }

            if (maximumResponseBytes < 0xBD8)
            {
                throw new ArgumentOutOfRangeException(nameof(maximumResponseBytes));
            }

            return WindowsStorageSpacesPoolReader.TryReadSpaceExtents(
                pool, space, OS.IsWindows() ? StorageIoControlFactory.Create() : null,
                maximumResponseBytes, out extentInfo);
        }

        /// <summary>
        /// Refreshes the current state of the specified storage device. Partitions are checked
        /// when <see cref="PartitionRefreshInterval"/> has elapsed since the last attempt.
        /// </summary>
        /// <param name="device">The device to refresh.</param>
        /// <returns>Whether the device state was successfully refreshed or device had no changes.</returns>
        /// <remarks>After the first full probe, compatible devices reuse their cached successful probe path and refresh only volatile disk data where possible.<br/>
        /// Polling HDD SMART data too frequently may cause performance degradation or audible clicking on some drives or USB/SATA bridges.<br/>
        /// Applications should throttle HDD refresh intervals appropriately.</remarks>
        public static bool Refresh(StorageDevice device)
        {
            return Refresh(device, true, IsPartitionRefreshDue(device), true);
        }

        /// <summary>
        /// Refreshes the current state of the specified storage device. Partitions are checked
        /// when <see cref="PartitionRefreshInterval"/> has elapsed since the last attempt.
        /// </summary>
        /// <param name="device">The device to refresh.</param>
        /// <param name="refreshSmartData">Whether to refresh SMART data. When disabled, previously collected SMART data is retained.</param>
        /// <returns>Whether the device state was successfully refreshed or device had no changes.</returns>
        /// <remarks>After the first full probe, compatible devices reuse their cached successful probe path and refresh only volatile disk data where possible.<br/>
        /// Polling HDD SMART data too frequently may cause performance degradation or audible clicking on some drives or USB/SATA bridges.<br/>
        /// Applications should throttle HDD refresh intervals appropriately.</remarks>
        public static bool Refresh(StorageDevice device, bool refreshSmartData)
        {
            return Refresh(device, true, IsPartitionRefreshDue(device), refreshSmartData);
        }

        /// <summary>
        /// Refreshes the volatile data of the specified storage device.
        /// </summary>
        /// <param name="device">The device to refresh.</param>
        /// <returns>Whether the volatile data was successfully refreshed or device had no changes.</returns>
        /// <remarks>After the first full probe, compatible devices reuse their cached successful probe path and refresh only volatile disk data where possible.<br/>
        /// Polling HDD SMART data too frequently may cause performance degradation or audible clicking on some drives or USB/SATA bridges.<br/>
        /// Applications should throttle HDD refresh intervals appropriately.</remarks>
        public static bool RefreshVolatileData(StorageDevice device)
        {
            return Refresh(device, true, false, true);
        }

        /// <summary>
        /// Refreshes the partitions of the specified storage device.
        /// </summary>
        /// <param name="device">The device to refresh.</param>
        /// <returns>Whether the partitions were successfully refreshed or device had no changes.</returns>
        public static bool RefreshPartitions(StorageDevice device)
        {
            if (device == null)
            {
                throw new ArgumentNullException(nameof(device));
            }

            bool excludeUsbDevices = ExcludeUsbDevices;

            if (excludeUsbDevices && UsbStorageDeviceIdentifier.IsUsbDevice(device))
            {
                return false;
            }

            bool changed = StoragePartitionReader.PopulatePartitions(device, StorageIoControlFactory.Create(), null, !excludeUsbDevices);

            device.LastUpdatedUtc = DateTime.UtcNow;
            return changed;
        }

        /// <summary>
        /// Refreshes the current state of the specified storage device.
        /// </summary>
        /// <param name="device">The device to refresh.</param>
        /// <param name="refreshProbeData">Whether to refresh the probe data.</param>
        /// <param name="refreshPartitions">Whether to refresh the partitions.</param>
        /// <returns>Whether the device state was successfully refreshed or device had no changes.</returns>
        /// <remarks>After the first full probe, compatible devices reuse their cached successful probe path and refresh only volatile disk data where possible.<br/>
        /// Polling HDD SMART data too frequently may cause performance degradation or audible clicking on some drives or USB/SATA bridges.<br/>
        /// Applications should throttle HDD refresh intervals appropriately.</remarks>
        public static bool Refresh(StorageDevice device, bool refreshProbeData, bool refreshPartitions)
        {
            return Refresh(device, refreshProbeData, refreshPartitions, true);
        }

        /// <summary>
        /// Refreshes the current state of the specified storage device.
        /// </summary>
        /// <param name="device">The device to refresh.</param>
        /// <param name="refreshProbeData">Whether to refresh the probe data.</param>
        /// <param name="refreshPartitions">Whether to refresh the partitions.</param>
        /// <param name="refreshSmartData">Whether to refresh SMART data as part of the probe data refresh. When disabled, previously collected SMART data is retained.</param>
        /// <returns>Whether the device state was successfully refreshed or device had no changes.</returns>
        /// <remarks>After the first full probe, compatible devices reuse their cached successful probe path and refresh only volatile disk data where possible.<br/>
        /// Polling HDD SMART data too frequently may cause performance degradation or audible clicking on some drives or USB/SATA bridges.<br/>
        /// Applications should throttle HDD refresh intervals appropriately.</remarks>
        public static bool Refresh(StorageDevice device, bool refreshProbeData, bool refreshPartitions, bool refreshSmartData)
        {
            if (device == null)
            {
                throw new ArgumentNullException(nameof(device));
            }

            bool excludeUsbDevices = ExcludeUsbDevices;

            if (excludeUsbDevices && UsbStorageDeviceIdentifier.IsUsbDevice(device))
            {
                return false;
            }

            var ioControl = StorageIoControlFactory.Create();
            var refreshed = StorageDeviceCloneHelper.Clone(device);

            if (refreshProbeData)
            {
                RefreshSingleDeviceProbeData(refreshed, ioControl, refreshSmartData);
            }

            if (refreshPartitions)
            {
                StoragePartitionReader.PopulatePartitions(refreshed, ioControl, null, !excludeUsbDevices);
            }

            refreshed.LastUpdatedUtc = DateTime.UtcNow;
            return StorageDeviceCloneHelper.CopyInto(refreshed, device);
        }

        /// <summary>
        /// Starts monitoring storage devices for changes.
        /// </summary>
        public static void StartMonitoring()
        {
            lock (SyncRoot)
            {
                _explicitMonitoringStarted = true;
            }

            EnsureMonitoringStarted();
        }

        /// <summary>
        /// Stops explicit storage device monitoring when no event subscribers are registered.
        /// </summary>
        public static void StopMonitoring()
        {
            lock (SyncRoot)
            {
                _explicitMonitoringStarted = false;
            }

            StopMonitoringIfUnused();
        }

        /// <summary>
        /// Refreshes the cached disks.
        /// </summary>
        public static void RefreshCachedDisks()
        {
            EnsureMonitoringStarted();
            HandleStorageTopologyChanged();
        }

        /// <summary>
        /// Attempts to wake up the specified device if it is currently powered off.
        /// </summary>
        /// <param name="device">The storage device to wake up. Must not be null.</param>
        public static void TryWakeUp(StorageDevice device)
        {
            if (device == null)
            {
                throw new ArgumentNullException(nameof(device));
            }

            if (ExcludeUsbDevices && UsbStorageDeviceIdentifier.IsUsbDevice(device))
            {
                return;
            }

            var ioControl = StorageIoControlFactory.Create();

            SafeFileHandle handle;

            if (OS.IsWindows() && ioControl is WindowsStorageIoControl windowsIo)
            {
                handle = windowsIo.OpenDeviceSynchronous(
                    device.DevicePath,
                    IoAccess.GenericRead,
                    IoShare.ReadWrite,
                    IoCreation.OpenExisting,
                    IoFlags.Normal);
            }
            else
            {
                handle = ioControl.OpenDevice(
                    device.DevicePath,
                    IoAccess.GenericRead,
                    IoShare.ReadWrite,
                    IoCreation.OpenExisting,
                    IoFlags.Normal);
            }

            using (handle)
            {
                var buffer = new byte[512];

                if (OS.IsWindows())
                {
                    Kernel32Native.SetFilePointerEx(handle, 0, IntPtr.Zero, 0);
                    Kernel32Native.ReadFile(handle, buffer, (uint)buffer.Length, out _, IntPtr.Zero);
                }
                else
                {
                    using (var stream = new FileStream(handle, FileAccess.Read))
                    {
#pragma warning disable CA2022 //Avoid inexact read with Stream.Read
                        stream.Read(buffer, 0, buffer.Length);
#pragma warning restore CA2022 //Avoid inexact read with Stream.Read
                    }
                }
            }
        }

        #endregion

        #region Internal

        internal static ILocalizedTextProvider GetTextProvider()
        {
            lock (SyncRoot)
            {
                if (_resourceManager == null)
                {
                    _resourceBaseName = ResolveResourceBaseName(typeof(Storage).Assembly);
                    if (!string.IsNullOrWhiteSpace(_resourceBaseName))
                    {
                        _resourceManager = new ResourceManager(_resourceBaseName, typeof(Storage).Assembly);
                    }
                }

                return _resourceManager != null
                    ? new ResourceManagerLocalizedTextProvider(_resourceManager, _resourceCulture)
                    : null;
            }
        }

        internal static string ResolveResourceBaseName(Assembly assembly)
        {
            if (assembly == null)
            {
                return string.Empty;
            }

            var resourceNames = assembly.GetManifestResourceNames();
            if (resourceNames == null || resourceNames.Length == 0)
            {
                return string.Empty;
            }

            const string preferredSuffix = ".Resources.Resources.resources";
            const string fallbackSuffix = ".Resources.resources";
            const string resourceExtension = ".resources";

            foreach (var resourceName in resourceNames)
            {
                if (resourceName != null && resourceName.EndsWith(preferredSuffix, StringComparison.Ordinal))
                {
                    return resourceName.Substring(0, resourceName.Length - resourceExtension.Length);
                }
            }

            foreach (var resourceName in resourceNames)
            {
                if (resourceName != null && resourceName.EndsWith(fallbackSuffix, StringComparison.Ordinal))
                {
                    return resourceName.Substring(0, resourceName.Length - resourceExtension.Length);
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Carries the last complete layout through an unsuccessful topology scan when
        /// the device identity is known. Disk number alone is unsafe after hotplug.
        /// </summary>
        /// <param name="previous">The last published device snapshot.</param>
        /// <param name="current">The newly enumerated devices to update.</param>
        internal static void PreservePartitionSnapshotsOnFailure(
            IReadOnlyList<StorageDevice> previous, IReadOnlyList<StorageDevice> current)
        {
            foreach (var disk in current)
            {
                if (!disk.PartitionsAreStale)
                {
                    continue;
                }

                var earlier = previous.FirstOrDefault(old =>
                    !string.IsNullOrWhiteSpace(disk.DeviceInstanceID)
                 && !string.IsNullOrWhiteSpace(old.DeviceInstanceID)
                 && string.Equals(disk.DeviceInstanceID, old.DeviceInstanceID, StringComparison.OrdinalIgnoreCase));

                if (earlier == null && string.IsNullOrWhiteSpace(disk.DeviceInstanceID))
                {
                    earlier = previous.FirstOrDefault(old =>
                        !string.IsNullOrWhiteSpace(disk.DevicePath)
                     && !string.IsNullOrWhiteSpace(old.DevicePath)
                     && !disk.DevicePath.StartsWith(@"\\.\PhysicalDrive", StringComparison.OrdinalIgnoreCase)
                     && string.Equals(disk.DevicePath, old.DevicePath, StringComparison.OrdinalIgnoreCase));
                }

                if (earlier?.PartitionsLastReadUtc.HasValue == true)
                {
                    var saved = StorageDeviceCloneHelper.Clone(earlier);

                    disk.Partitions            = saved.Partitions;
                    disk.PartitionsLastReadUtc = saved.PartitionsLastReadUtc;
                }
            }
        }

        #endregion

        #region Private

        /// <summary>
        /// Enumerates devices and builds the visible and removable-media snapshots.
        /// </summary>
        /// <param name="excludeUsbDevices">Whether USB devices are excluded for this scan.</param>
        /// <param name="visibleDisks">The devices shown to callers.</param>
        /// <param name="mediaWatchDevices">Devices whose media presence is monitored.</param>
        /// <param name="mediaStates">The current removable-media states.</param>
        private static void EnumerateStorageState(bool excludeUsbDevices, out List<StorageDevice> visibleDisks, out List<StorageDevice> mediaWatchDevices, out Dictionary<string, bool?> mediaStates)
        {
            //Get the raw list of disks
            var rawDisks = EnumerateRawDisks(excludeUsbDevices);

            //Extract the media-watch candidates and build the media presence state snapshot before filtering
            mediaWatchDevices = StorageMediaPresenceMonitor.ExtractMediaWatchDevices(rawDisks);

            //Build the media presence state snapshot before filtering,
            //so that devices that are filtered due to no media presence are still monitored for media changes
            mediaStates = StorageMediaPresenceMonitor.BuildStateSnapshot(mediaWatchDevices);

            //Filter the raw list to the visible list
            visibleDisks = StorageDeviceCloneHelper.CloneList(rawDisks);

            //Filter out devices that should not be visible
            StorageMediaPresenceMonitor.FilterNoMediaDevices(visibleDisks, mediaStates);
        }

        /// <summary>
        /// Detects disks and reads their partitions with one shared volume extent cache.
        /// </summary>
        /// <returns>The detected disks before visibility filtering.</returns>
        private static List<StorageDevice> EnumerateRawDisks(bool excludeUsbDevices)
        {
            var engine = new StorageDetectionEngine(StorageIoControlFactory.Create());

            //Get the raw list of disks
            var disks = engine.GetDisks(excludeUsbDevices);
            var ioControl = StorageIoControlFactory.Create();
            var volumeExtents = new WindowsVolumeExtentMap(ioControl);

            if (ioControl is WindowsStorageIoControl windowsIo)
            {
                foreach (var disk in disks)
                {
                    windowsIo.RegisterDeviceAliases(disk);
                }
            }

            foreach (var disk in disks)
            {
                //Populate the partitions for all disks
                StoragePartitionReader.PopulatePartitions(disk, ioControl, volumeExtents, !excludeUsbDevices);

                disk.LastUpdatedUtc = DateTime.UtcNow;
            }

            return disks;
        }

        /// <summary>
        /// Checks whether a default device refresh should attempt another partition read.
        /// </summary>
        /// <param name="device">The device being refreshed.</param>
        /// <returns>Whether the configured interval has elapsed since its last attempt.</returns>
        private static bool IsPartitionRefreshDue(StorageDevice device)
        {
            if (device == null)
            {
                throw new ArgumentNullException(nameof(device));
            }

            TimeSpan interval = PartitionRefreshInterval;
            return OS.IsWindows() && interval > TimeSpan.Zero
                && (!device.PartitionsLastCheckedUtc.HasValue
                    || DateTime.UtcNow - device.PartitionsLastCheckedUtc.Value >= interval);
        }

        private static void RefreshSingleDeviceProbeData(StorageDevice device, IStorageIoControl ioControl, bool refreshSmartData)
        {
            if (device == null || ioControl == null)
            {
                return;
            }

            bool canUseCachedProbePlan = CanUseCachedProbePlanForRefresh(device);

            device.ProbeTrace = new List<string>();

            if (!canUseCachedProbePlan)
            {
                if (refreshSmartData)
                {
                    ResetVolatileProbeData(device);
                }

                //Refresh the IOCTL-backed base properties for this single device only
                //Do not enumerate all disks here
                StorageDetectionEngine.AttachStandardStorageProperties(device, ioControl, refreshSmartData);
                StorageDetectionEngine.SelectProbeStrategy(device);
            }

            if (!device.IsFiltered)
            {
                StorageProbeDispatcher.Probe(device, ioControl, refreshSmartData);
            }
        }

        private static bool CanUseCachedProbePlanForRefresh(StorageDevice device)
        {
            StorageProbePlan plan = device != null ? device.ProbePlan : null;
            return plan != null && plan.IsInitialized && plan.IsCompatibleWith(device);
        }

        private static void ResetVolatileProbeData(StorageDevice device)
        {
            device.SupportsSmart = false;
            device.SmartVersionRaw = 0;
            device.PredictsFailure = null;
            device.PredictFailureVendorData = Array.Empty<byte>();
            device.SmartAttributes = new List<SmartAttributeEntry>();
            device.SmartAttributeProfile = SmartAttributeProfile.Unknown;
            device.ProbeTrace = new List<string>();
            device.Nvme = new StorageNvmeInfo();
            device.CapacitySource = string.Empty;
        }

        private static void EnsureMonitoringStarted()
        {
            while (true)
            {
                Thread messageLoopThread;
                Thread rescanThread;
                Thread mediaWatchThread;

                lock (SyncRoot)
                {
                    if (!ShouldKeepMonitoringAliveLocked())
                    {
                        return;
                    }

                    if (_monitoringStarted && !_monitoringStopping)
                    {
                        return;
                    }

                    if (_monitoringStopping)
                    {
                        CaptureMonitoringThreadsLocked(out messageLoopThread, out rescanThread, out mediaWatchThread);
                    }
                    else
                    {
                        StartMonitoringLocked();
                        return;
                    }
                }

                WaitForMonitoringThreads(messageLoopThread, rescanThread, mediaWatchThread);

                lock (SyncRoot)
                {
                    CompleteMonitoringStopLocked();
                }
            }
        }

        private static void StartMonitoringLocked()
        {
            _monitoringStopping = false;
            MonitoringStopSignal.Reset();

            //Get the initial storage state before starting the monitoring threads, so that we have a baseline for change detection and can populate the media watch state
            EnumerateStorageState(_excludeUsbDevices, out var initialVisibleDisks, out var initialMediaWatchDevices, out var initialMediaStates);

            _currentDisks = StorageDeviceCloneHelper.CloneList(initialVisibleDisks);
            _mediaWatchDevices = StorageDeviceCloneHelper.CloneList(initialMediaWatchDevices);
            _removableMediaStates = initialMediaStates;

            //Start rescan thread, which rescans the storage state when signaled by the message loop thread or media watch loop
            _rescanThread = new Thread(RescanLoop)
            {
                IsBackground = true,
                Name = $"{nameof(Storage)}.{nameof(RescanLoop)}"
            };
            _rescanThread.Start();

            //Start the message loop thread, which listens for device change notifications and signals rescans
            _messageLoopThread = new Thread(MessageLoop)
            {
                IsBackground = true,
                Name = $"{nameof(Storage)}.{nameof(MessageLoop)}"
            };
            _messageLoopThread.Start();

            //Start the media watch loop thread, which periodically checks for removable media state changes and signals rescans.
            //This is required on Linux as well, because some SD/MMC/card-reader stacks keep the same block-device topology while the medium changes.
            _mediaWatchThread = new Thread(MediaWatchLoop)
            {
                IsBackground = true,
                Name = $"{nameof(Storage)}.{nameof(MediaWatchLoop)}"
            };
            _mediaWatchThread.Start();

            _monitoringStarted = true;
        }

        private static void StopMonitoringIfUnused()
        {
            Thread messageLoopThread;
            Thread rescanThread;
            Thread mediaWatchThread;

            lock (SyncRoot)
            {
                if (ShouldKeepMonitoringAliveLocked())
                {
                    return;
                }

                RequestMonitoringStopLocked(out messageLoopThread, out rescanThread, out mediaWatchThread);
            }

            WaitForMonitoringThreads(messageLoopThread, rescanThread, mediaWatchThread);

            lock (SyncRoot)
            {
                CompleteMonitoringStopLocked();
            }
        }

        private static bool ShouldKeepMonitoringAliveLocked()
        {
            return _devicesChanged != null || _explicitMonitoringStarted;
        }

        private static void RequestMonitoringStopLocked(out Thread messageLoopThread, out Thread rescanThread, out Thread mediaWatchThread)
        {
            CaptureMonitoringThreadsLocked(out messageLoopThread, out rescanThread, out mediaWatchThread);

            if (!_monitoringStarted || _monitoringStopping)
            {
                return;
            }

            _monitoringStopping = true;

            MonitoringStopSignal.Set();
            RescanSignal.Set();
            PartitionRefreshScheduleSignal.Set();

            if (OS.IsWindows())
            {
                WindowsStorageDeviceChangeMonitor.RequestStop();
            }
        }

        private static void CaptureMonitoringThreadsLocked(out Thread messageLoopThread, out Thread rescanThread, out Thread mediaWatchThread)
        {
            messageLoopThread = _messageLoopThread;
            rescanThread      = _rescanThread;
            mediaWatchThread  = _mediaWatchThread;
        }

        private static void CompleteMonitoringStopLocked()
        {
            if (!_monitoringStopping)
            {
                return;
            }

            _monitoringStarted  = false;
            _monitoringStopping = false;

            _messageLoopThread = null;
            _rescanThread      = null;
            _mediaWatchThread  = null;
        }

        private static void WaitForMonitoringThreads(Thread messageLoopThread, Thread rescanThread, Thread mediaWatchThread)
        {
            WaitForMonitoringThread(messageLoopThread);
            WaitForMonitoringThread(rescanThread);
            WaitForMonitoringThread(mediaWatchThread);
        }

        private static void WaitForMonitoringThread(Thread thread)
        {
            if (thread == null || !thread.IsAlive || ReferenceEquals(Thread.CurrentThread, thread))
            {
                return;
            }

            thread.Join(MonitoringThreadStopTimeoutMilliseconds);
        }

        private static void MessageLoop()
        {
            if (OS.IsWindows())
            {
                WindowsStorageDeviceChangeMonitor.Run(MonitoringStopSignal, QueueRescan);
                return;
            }

            if (OS.IsLinux())
            {
                LinuxStorageDeviceChangeMonitor.Run(MonitoringStopSignal, QueueRescan);
            }
        }

        private static void QueueRescan()
        {
            RescanSignal.Set();
        }

        private static void MediaWatchLoop()
        {
            while (!MonitoringStopSignal.WaitOne(0))
            {
                var delay = MediaWatchLoopDelay;

                if (MonitoringStopSignal.WaitOne(delay))
                {
                    return;
                }

                try
                {
                    if (CheckForRemovableMediaStateChanges())
                    {
                        QueueRescan();
                    }
                }
                catch
                {
                }
            }
        }

        private static bool CheckForRemovableMediaStateChanges()
        {
            lock (ScanRoot)
            {
                return CheckForRemovableMediaStateChangesCore();
            }
        }

        private static bool CheckForRemovableMediaStateChangesCore()
        {
            List<StorageDevice> snapshot;
            Dictionary<string, bool?> previousStates;
            bool excludeUsbDevices;

            lock (SyncRoot)
            {
                snapshot = StorageDeviceCloneHelper.CloneList(_mediaWatchDevices);
                previousStates = new Dictionary<string, bool?>(_removableMediaStates, StringComparer.OrdinalIgnoreCase);

                excludeUsbDevices = _excludeUsbDevices;
            }

            if (excludeUsbDevices)
            {
                snapshot.RemoveAll(UsbStorageDeviceIdentifier.IsUsbDevice);
            }

            var currentStates = StorageMediaPresenceMonitor.BuildStateSnapshot(snapshot);
            bool changed = !MediaStateDictionariesEqual(previousStates, currentStates);

            if (changed)
            {
                lock (SyncRoot)
                {
                    _removableMediaStates = currentStates;
                }
            }

            return changed;
        }

        private static List<StorageDevice> MergeMediaWatchDevicesForMonitoring(List<StorageDevice> previous, List<StorageDevice> current)
        {
            if (!OS.IsLinux())
            {
                return StorageDeviceCloneHelper.CloneList(current);
            }

            var result = new List<StorageDevice>();
            var keys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            AddMediaWatchDevices(result, keys, current);
            AddMediaWatchDevices(result, keys, previous);

            return result;
        }

        private static void AddMediaWatchDevices(List<StorageDevice> result, HashSet<string> keys, List<StorageDevice> devices)
        {
            if (result == null || keys == null || devices == null)
            {
                return;
            }

            foreach (var device in devices)
            {
                if (!StorageMediaPresenceMonitor.IsMediaWatchCandidate(device))
                {
                    continue;
                }

                string key = GetMediaWatchKey(device);
                if (string.IsNullOrWhiteSpace(key) || keys.Contains(key))
                {
                    continue;
                }

                keys.Add(key);
                result.Add(StorageDeviceCloneHelper.Clone(device));
            }
        }

        private static string GetMediaWatchKey(StorageDevice device)
        {
            if (device == null)
            {
                return string.Empty;
            }

            string key = StorageDeviceIdentityMatcher.GetStableKey(device);
            if (!string.IsNullOrWhiteSpace(key))
            {
                return key;
            }

            if (!string.IsNullOrWhiteSpace(device.DevicePath))
            {
                return device.DevicePath;
            }

            if (!string.IsNullOrWhiteSpace(device.AlternateDevicePath))
            {
                return device.AlternateDevicePath;
            }

            return device.DeviceInstanceID ?? string.Empty;
        }

        private static bool MediaStateDictionariesEqual(Dictionary<string, bool?> left, Dictionary<string, bool?> right)
        {
            if (ReferenceEquals(left, right))
            {
                return true;
            }

            if (left == null || right == null)
            {
                return false;
            }

            if (left.Count != right.Count)
            {
                return false;
            }

            foreach (var pair in left)
            {
                if (!right.TryGetValue(pair.Key, out var otherValue))
                {
                    return false;
                }

                if (pair.Value != otherValue)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Processes topology signals and scheduled partition checks on the monitoring thread.
        /// </summary>
        private static void RescanLoop()
        {
            WaitHandle[] waitHandles =
            {
                RescanSignal,
                MonitoringStopSignal,
                PartitionRefreshScheduleSignal
            };

            DateTime nextPartitionRefreshUtc = GetNextPartitionRefreshUtc();

            while (true)
            {
                int timeout = nextPartitionRefreshUtc == DateTime.MaxValue
                    ? Timeout.Infinite
                    : Math.Max(0, (int)Math.Min(int.MaxValue, (nextPartitionRefreshUtc - DateTime.UtcNow).TotalMilliseconds));

                int signal = WaitHandle.WaitAny(waitHandles, timeout);

                if (signal == 1)
                {
                    return;
                }

                if (signal == 2)
                {
                    nextPartitionRefreshUtc = GetNextPartitionRefreshUtc();

                    continue;
                }

                if (signal == WaitHandle.WaitTimeout)
                {
                    try
                    {
                        HandlePartitionRefresh();
                    }
                    catch
                    {
                    }

                    nextPartitionRefreshUtc = GetNextPartitionRefreshUtc();

                    continue;
                }

                if (MonitoringStopSignal.WaitOne(250))
                {
                    return;
                }

                while (RescanSignal.WaitOne(0))
                {
                }

                try
                {
                    HandleStorageTopologyChanged();
                }
                catch
                {
                }

                nextPartitionRefreshUtc = GetNextPartitionRefreshUtc();

                if (MonitoringStopSignal.WaitOne(0))
                {
                    return;
                }
            }
        }

        /// <summary>
        /// Calculates the next partition check from the current interval setting.
        /// </summary>
        /// <returns>The next UTC check time, or <see cref="DateTime.MaxValue"/> when disabled.</returns>
        private static DateTime GetNextPartitionRefreshUtc()
        {
            TimeSpan interval = PartitionRefreshInterval;

            return !OS.IsWindows() || interval == TimeSpan.Zero
                 ? DateTime.MaxValue
                 : DateTime.UtcNow.Add(interval);
        }

        /// <summary>
        /// Refreshes monitored partition snapshots without repeating hardware probes.
        /// </summary>
        private static void HandlePartitionRefresh()
        {
            lock (ScanRoot)
            {
                HandlePartitionRefreshCore();
            }
        }

        private static void HandlePartitionRefreshCore()
        {
            if (!OS.IsWindows())
            {
                return;
            }

            List<StorageDevice> previous;
            bool excludeUsbDevices;

            lock (SyncRoot)
            {
                previous = StorageDeviceCloneHelper.CloneList(_currentDisks);
                excludeUsbDevices = _excludeUsbDevices;
            }

            var current = StorageDeviceCloneHelper.CloneList(previous);

            if (excludeUsbDevices)
            {
                current.RemoveAll(UsbStorageDeviceIdentifier.IsUsbDevice);
            }

            var ioControl = StorageIoControlFactory.Create();

            var volumeExtents = new WindowsVolumeExtentMap(ioControl);

            if (ioControl is WindowsStorageIoControl windowsIo)
            {
                foreach (var disk in current)
                {
                    windowsIo.RegisterDeviceAliases(disk);
                }
            }

            foreach (var disk in current)
            {
                if (disk.IsDevicePowerOn == false)
                {
                    continue;
                }

                StoragePartitionReader.PopulatePartitions(disk, ioControl, volumeExtents, !excludeUsbDevices);
            }

            var diff = StorageDeviceDiffBuilder.Build(previous, current);

            lock (SyncRoot)
            {
                _currentDisks = StorageDeviceCloneHelper.CloneList(current);
            }

            if (diff.HasChanges)
            {
                _devicesChanged?.Invoke(null, diff);
            }
        }

        /// <summary>
        /// Re-enumerates devices after a topology signal and publishes the resulting changes.
        /// </summary>
        private static void HandleStorageTopologyChanged()
        {
            lock (ScanRoot)
            {
                HandleStorageTopologyChangedCore();
            }
        }

        private static void HandleStorageTopologyChangedCore()
        {
            List<StorageDevice> previous;
            List<StorageDevice> previousMediaWatchDevices;
            bool excludeUsbDevices;

            lock (SyncRoot)
            {
                //Clone the previous state to avoid holding the lock during the potentially long enumeration and diffing operations
                previous = StorageDeviceCloneHelper.CloneList(_currentDisks);
                previousMediaWatchDevices = StorageDeviceCloneHelper.CloneList(_mediaWatchDevices);

                excludeUsbDevices = _excludeUsbDevices;
            }

            //Get the new state
            EnumerateStorageState(excludeUsbDevices, out var current, out var mediaWatchDevices, out var mediaStates);

            PreservePartitionSnapshotsOnFailure(previous, current);

            var mergedMediaWatchDevices = MergeMediaWatchDevicesForMonitoring(previousMediaWatchDevices, mediaWatchDevices);

            if (excludeUsbDevices)
            {
                mergedMediaWatchDevices.RemoveAll(UsbStorageDeviceIdentifier.IsUsbDevice);
            }

            var mergedMediaStates = OS.IsLinux()
                ? StorageMediaPresenceMonitor.BuildStateSnapshot(mergedMediaWatchDevices)
                : mediaStates;

            //Build the difference between the previous and current state
            var diff = StorageDeviceDiffBuilder.Build(previous, current);

            if (OS.IsWindows())
            {
                var changedTopology = diff.Added.Concat(diff.Removed).ToList();

                foreach (var disk in diff.Updated)
                {
                    var earlier = previous.FirstOrDefault(old =>
                        !string.IsNullOrWhiteSpace(disk.DeviceInstanceID)
                     && string.Equals(old.DeviceInstanceID, disk.DeviceInstanceID, StringComparison.OrdinalIgnoreCase));

                    if (earlier != null && earlier.StorageDeviceNumber != disk.StorageDeviceNumber)
                    {
                        changedTopology.Add(disk);
                    }
                }

                if (changedTopology.Count != 0)
                {
                    WindowsStorageIoControl.ClearTimeoutCooldownForTopologyChange(changedTopology);

                    RescanSignal.Set();
                }
            }

            lock (SyncRoot)
            {
                _currentDisks      = StorageDeviceCloneHelper.CloneList(current);
                _mediaWatchDevices = StorageDeviceCloneHelper.CloneList(mergedMediaWatchDevices);

                _removableMediaStates = mergedMediaStates;
            }

            //Raise change event if there are any changes
            if (diff.HasChanges)
            {
                _devicesChanged?.Invoke(null, diff);
            }
        }

        #endregion
    }
}
