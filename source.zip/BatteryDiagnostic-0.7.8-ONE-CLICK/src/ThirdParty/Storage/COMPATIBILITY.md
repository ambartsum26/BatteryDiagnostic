# Storage compatibility — Battery Diagnostic Portable 0.6.3

Own C# collectors and assessment engine. No CrystalDiskInfo executable/library is required. Uses documented Windows disk IOCTLs and selected rules informed by MIT-licensed CrystalDiskInfo; attribution is in embedded ThirdPartyNotices.txt.

Read-only transport: ATA_PASS_THROUGH_EX, SMART_RCV_DRIVE_DATA, SAT-12 A1/SAT-16 85 in SCSI_PASS_THROUGH. PIO data-in, one512-byte sector, CK_COND disabled. Only IDENTIFY EC, SMART B0/D0 and B0/D1 are allowed. CHECK CONDITION, short data, corrupt offsets/status/checksums, duplicate attribute IDs and unbound USB model identity are rejected. No enable/write/self-test, bridge mode changes or driver installation.

USB model matching is intentionally strict. Enclosures exposing an unrelated Windows model are not accepted. Vendor-specific USB–NVMe, RAID/RST/VROC/CSMI/MegaRAID and proprietary bridge libraries remain unsupported. Standard SAT must still be validated on actual bridges.

| ATA family | Resource interpretation |
| --- | --- |
| SK hynix SC311/SC401 | E7/E9 low raw byte remaining; multiple fields must agree |
| HFS TND/MND | E7/E9 low raw byte consumed; remaining=100-consumed |
| HFS TNF | E7/E9 low raw byte remaining |
| Samsung SSD470/750/830/840/850/860/870 | B1 normalized Current remaining, not raw erase count |
| Crucial CT/Crucial_CT MX/BX100/200/300/500; Micron1100/1300 | CA normalized Current remaining |
| Intel SSDSC2BW/BP/CT/CW, SSDSA2CW | E9 normalized Current remaining |

Profiles require known model families and valid values0..100. Conflicts or a confirmed HDD media type prevent SSD resource assignment. Unknown families are not guessed. Hardware models are discovered automatically; users do not maintain a manual list.

ATA temperature uses C2/BE low raw byte for supported SSD profiles or conventional rotating ATA drives, excluding SamsungSV legacy encodings.09 raw hours are decoded only for SC311/SC401; other families can use different units. Threshold comparison excludes C2 and sentinel values: below is bad, equality is conservative caution. HDD05/C5/C6 low16-bit counts produce warnings; upper-only ambiguous values remain unavailable. No universal HDD percentage.

NVMe: validated512-byte health log, remaining=max(0,100-PercentageUsed). Composite temperature and8sensors decode Kelvin to Celsius; zero/FFFF/implausible temperatures are absent. CriticalWarning and AvailableSpare/threshold are independent from endurance. Nonzero critical warning or spare below threshold is bad; equality at thresholds1..99 is caution. Invalid logs never imply healthy100%.

Condition/resource are separate UI fields. Faults have priority. Known SATA resource0 is bad; NVMe resource0 without other flags is caution. A negative failure prediction alone is insufficient. Contradictory controller data cannot become good through a provider fallback.

SMART details show actual normalized Current/Worst/Threshold and raw hexadecimal values. They use the existing background snapshot, clear readings after45seconds and issue no device commands. This is not a surface scan, NAND-cell test or independent temperature calibration.

Primary sources reviewed2026-10-20/21:

- https://github.com/hiyohiyo/CrystalDiskInfo/blob/master/AtaSmart.cpp — CheckDiskStatus, FillSmartData, IsSsdMicronMU03, IsSsdSKhynix, SAT construction.
- https://crystalmark.info/en/software/crystaldiskinfo/crystaldiskinfo-health-status/
- https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntddscsi/ns-ntddscsi-_scsi_pass_through
- https://learn.microsoft.com/en-us/windows/win32/api/nvme/ns-nvme-nvme_health_info_log

Synthetic parser/protocol/UI tests verify implementation, not hardware coverage. Physical ATA/NVMe/SAT reads depend on the drive, bridge and Windows access rights. The current execution environment blocks physical-drive access. No kernel driver was installed or loaded during validation.