﻿using System.Globalization;
namespace BatteryDiagnostic;

internal sealed class Dashboard : UserControl
{
    readonly TableLayoutPanel root = new() { Dock=DockStyle.Fill, ColumnCount=1, RowCount=5, Padding=new Padding(16,8,16,8) };
    readonly RoundedPanel card = new() { Dock=DockStyle.Fill, Padding=new Padding(14), Margin=new Padding(0,6,0,6) };
    readonly TableLayoutPanel right = new() { Dock=DockStyle.Fill, ColumnCount=2, RowCount=5, Margin=Padding.Empty };
    readonly Label heading=LabelFor(17,true), model=LabelFor(9.5f,false,Theme.Muted);
    readonly Label system=LabelFor(10,true), batteryTitle=LabelFor(11,true), bottomState=LabelFor(9.5f,false,Theme.Muted);
    readonly Label healthCaption=LabelFor(9.5f,true), declaredCaption=LabelFor(9.5f,true), fullCaption=LabelFor(9.5f,true);
    readonly Label healthValue=LabelFor(11,true), declaredValue=LabelFor(11,true), fullValue=LabelFor(11,true);
    readonly Label batteryModel=LabelFor(10,false,Theme.Muted), manufacturer=LabelFor(10,false,Theme.Muted);
    readonly Label detailTime=LabelFor(9,false,Theme.Muted), notice=LabelFor(10,false,Theme.Warning), scope=LabelFor(9,false,Theme.Muted);
    readonly FlowLayoutPanel details=new() { Dock=DockStyle.Top, AutoSize=true, AutoSizeMode=AutoSizeMode.GrowAndShrink, FlowDirection=FlowDirection.TopDown, WrapContents=false, Visible=true, Padding=new Padding(0,8,0,0), Margin=Padding.Empty };
    readonly ToolTip tips=new() { AutoPopDelay=20000, InitialDelay=350 };
    internal readonly BatteryGauge Gauge=new() { Dock=DockStyle.Fill, Margin=new Padding(0) };
    internal readonly IndicatorWidget HealthIndicator=new(true), ChargeIndicator=new(false);
    
    UiLanguage lang=UiLanguage.French;
    BatteryData? data;
    Reading? reading;
    string error="";
    bool loaded;
    internal ChargeView CurrentCharge { get; private set; } = new(null,"sourceUnknown",null,null,"unknown");
    internal string CurrentHealth => healthValue.Text;
    string T(string key)=>L.Get(lang,key);
    string N(double value,string format="0.0")=>value.ToString(format,L.Culture(lang));

    internal Dashboard()
    {
        BackColor=Theme.Background; DoubleBuffered=true; AutoSize=false;
        foreach(var label in new[]{heading,model,notice,scope})label.BackColor=Theme.Background;
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute,32));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute,20));
        root.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        foreach(var label in new[]{notice,scope})
        {
            label.AutoSize=true; label.Dock=DockStyle.Top; label.Margin=Padding.Empty;
        }
        var columns=new TableLayoutPanel { Dock=DockStyle.Fill, ColumnCount=2, Margin=Padding.Empty };
        columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,31));
        columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,69));
        var left=new TableLayoutPanel { Dock=DockStyle.Fill, ColumnCount=1, RowCount=3, Margin=new Padding(0,0,18,0) };
        left.RowStyles.Add(new RowStyle(SizeType.Absolute,26));
        left.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute,42));
        bottomState.TextAlign=ContentAlignment.MiddleCenter;
        left.Controls.Add(system,0,0); left.Controls.Add(Gauge,0,1); left.Controls.Add(bottomState,0,2);
        right.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,210));
        right.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
        foreach(int h in new[]{30,40,40,40}) right.RowStyles.Add(new RowStyle(SizeType.Absolute,h));
        right.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        var group=new TableLayoutPanel { Dock=DockStyle.Fill, ColumnCount=2, Margin=Padding.Empty };
        group.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100)); group.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        var indicators=new FlowLayoutPanel { AutoSize=true, AutoSizeMode=AutoSizeMode.GrowAndShrink, FlowDirection=FlowDirection.LeftToRight, WrapContents=false, Anchor=AnchorStyles.Right, Margin=Padding.Empty };
        indicators.Controls.AddRange([HealthIndicator,ChargeIndicator]);
        group.Controls.Add(batteryTitle,0,0); group.Controls.Add(indicators,1,0);
        right.Controls.Add(group,0,0); right.SetColumnSpan(group,2);
        // Start each result and its caption at the same top baseline. This keeps
        // multi-line values (charge state and capacities) attached to their labels.
        foreach(var label in new[]{healthCaption,declaredCaption,fullCaption})
        {
            label.TextAlign=ContentAlignment.TopLeft;
            label.Padding=new Padding(0,2,4,0);
        }
        foreach(var label in new[]{healthValue,declaredValue,fullValue})
        {
            label.TextAlign=ContentAlignment.TopLeft;
            label.Padding=new Padding(0,2,4,0);
        }
        AddField(right,1,healthCaption,healthValue);
        AddField(right,2,declaredCaption,declaredValue); AddField(right,3,fullCaption,fullValue);
        foreach(var label in new[]{batteryModel,manufacturer,detailTime})
        {
            label.AutoSize=true; label.Dock=DockStyle.None; label.Margin=new Padding(0,0,0,9);
            details.Controls.Add(label);
        }
        right.Controls.Add(details,0,4); right.SetColumnSpan(details,2);
        columns.Controls.Add(left,0,0); columns.Controls.Add(right,1,0); card.Controls.Add(columns);
        root.Controls.Add(heading); root.Controls.Add(model); root.Controls.Add(card); root.Controls.Add(notice); root.Controls.Add(scope);
        notice.Margin=new Padding(0,0,0,6);
        Controls.Add(root);
        SetData(null,null,UiLanguage.French,"",false);
    }
    static Label LabelFor(float size,bool bold=false,Color? color=null)=>new()
    {
        Dock=DockStyle.Fill, ForeColor=color??Theme.Text, BackColor=Theme.Card,
        Font=new Font("Segoe UI",size,bold?FontStyle.Bold:FontStyle.Regular), Margin=Padding.Empty,
        TextAlign=ContentAlignment.MiddleLeft, AutoEllipsis=false, UseCompatibleTextRendering=true
    };
    static void AddField(TableLayoutPanel table,int row,Label caption,Label value){table.Controls.Add(caption,0,row);table.Controls.Add(value,1,row);}

    internal string Capacity(double? value)
    {
        if(!value.HasValue)return T("unknown");
        if(reading?.Relative==true)return N(value.Value,"0.##")+" "+T("relative");
        return N(value.Value/1000,"0.00")+" Wh";
    }
    internal void SetData(BatteryData? current,Reading? selected,UiLanguage language,string sourceError,bool completed)
    {
        data=current; reading=selected; lang=language; error=sourceError; loaded=completed;
        var charge=Engine.Charge(reading,data); CurrentCharge=charge;
        var assessment=reading==null?null:Engine.Evaluate(reading,lang);
        string percentage=charge.Percent.HasValue?L.Percent(lang,charge.Percent.Value):T("unknown");
        string state=T(charge.StateKey);
        string power=charge.StateKey=="charging"?T("charging")
            :charge.Online==true?T("online")
            :charge.Online==false?T("offline"):T("powerUnknown");
        heading.Text=T("information"); model.Text=data?.Machine is { Length:>0 } machine?machine:T("model")+": "+T("unknown");
        system.Text=T("system"); batteryTitle.Text=L.F(lang,"battery",(reading?.Slot??0)+1);
        healthCaption.Text=T("health");
        declaredCaption.Text=T("declared"); fullCaption.Text=T("full");
        string gradeText=assessment!=null?T(Engine.GradeLabelKey(assessment.Grade)):T("unknown");
        healthValue.Text=assessment?.Retained.HasValue==true?gradeText:T("unknown");
        Color healthColor=IndicatorWidget.HealthColor(assessment?.Grade);
        healthCaption.ForeColor=Theme.Text;
        healthValue.ForeColor=healthColor;
        declaredValue.Text=Capacity(reading?.Design); fullValue.Text=Capacity(reading?.Full);
        bottomState.Text=power;
        Gauge.UpdateCharge(charge,charge.Percent.HasValue?L.Percent(lang,charge.Percent.Value):"?",T("charge")+": "+percentage+"; "+state+"; "+power);
        string healthTip=assessment?.Retained is { } retainedForTip
            ?L.F(lang,"healthTip",Capacity(reading?.Full),Capacity(reading?.Design),L.Percent(lang,retainedForTip))
            :T("healthUnknown");
        string chargeTip=L.F(lang,"chargeTip",percentage+" · "+state,power,T(charge.SourceKey));
        HealthIndicator.SetValue(assessment?.Retained,T("health"),healthValue.Text+Environment.NewLine+healthTip,assessment?.Grade);
        ChargeIndicator.SetValue(charge.Percent,T("charge"),chargeTip);
        tips.SetToolTip(healthValue,healthTip); tips.SetToolTip(healthCaption,healthTip);
        batteryModel.Text=T("batteryModel")+": "+(reading?.BatteryModel??T("unknown"));
        tips.SetToolTip(batteryModel,T("batteryModelTip"));
        manufacturer.Text=T("manufacturer")+": "+(reading?.Manufacturer??T("unknown"));
        tips.SetToolTip(manufacturer,manufacturer.Text);
        var observation=reading?.Observation;
        detailTime.Text=observation!=null?L.F(lang,"observation",observation.Samples,observation.Seconds.ToString("0",L.Culture(lang))):T("observationUnknown");
                int observationNotes=(observation?.Findings.Length??0)+(assessment?.Signals.Count??0)+(assessment?.Notes.Count??0);
        if(observation!=null)detailTime.Text+=Environment.NewLine+(observationNotes>0?L.F(lang,"stabilityNotes",observationNotes):observation.ValidSamples<10||observation.Seconds<30?T("stabilityUnknown"):T("stabilityClear"));
        var evidence=new List<string> {T("passive")};
        if(observation==null || observation.Seconds<30 || observation.ValidSamples<10)evidence.Add(T("shortObservation"));
        else if(observationNotes==0)evidence.Add(T("noObservedSignal"));
        if(observation!=null)evidence.AddRange(observation.Findings.Select(T));
        if(assessment!=null){evidence.AddRange(assessment.Signals);evidence.AddRange(assessment.Notes);}
        tips.SetToolTip(detailTime,string.Join(Environment.NewLine,evidence));
        detailTime.Cursor=Cursors.Help;
        scope.Text=T("scope");
        var messages=new List<string>();
        if(!loaded)messages.Add(T("waiting"));
        else if(error.Length>0)messages.Add(T("errorRead")+" "+error);
        else if(reading==null)messages.Add(T("noBattery"));
        if(assessment!=null)
        {
            messages.AddRange(assessment.Signals.Select(s=>T("signals")+": "+s));
            messages.AddRange(assessment.Notes.Select(s=>T("quality")+": "+s));
        }
                if(observation!=null)messages.AddRange(observation.Findings.Select(code=>T("quality")+": "+T(code)));
        string allMessages=string.Join(Environment.NewLine,messages);
        notice.Text=messages.Count>0?messages[0]+(messages.Count>1?L.F(lang,"moreFindings",messages.Count-1):""):"";
        notice.Visible=messages.Count>0;notice.Cursor=Cursors.Help;
        tips.SetToolTip(notice,allMessages+Environment.NewLine+string.Join(Environment.NewLine,evidence));
        detailTime.AccessibleDescription=string.Join(Environment.NewLine,evidence);
        notice.AccessibleDescription=allMessages;
        notice.ForeColor=assessment?.Signals.Count>0?Theme.Danger:Theme.Warning;
        AccessibleName=T("information"); AccessibleDescription=healthCaption.Text+": "+healthValue.Text+"; "+bottomState.Text+"; "+declaredCaption.Text+": "+declaredValue.Text+"; "+fullCaption.Text+": "+fullValue.Text+"; "+notice.Text;
        FitFieldRows();
    }
    void FitFieldRows()
    {
        if(right.IsDisposed||right.ClientSize.Width<=0)return;
        var columns=right.GetColumnWidths();
        var rows=new (Label Caption,Label Value)[]
        {
            (healthCaption,healthValue),(declaredCaption,declaredValue),(fullCaption,fullValue)
        };
        for(int i=0;i<rows.Length;i++)
        {
            var (caption,value)=rows[i];
            int captionWidth=Math.Max(1,(caption.Width>0?caption.Width:columns[0])-caption.Padding.Horizontal);
            int valueWidth=Math.Max(1,(value.Width>0?value.Width:columns[1])-value.Padding.Horizontal);
            int needed=Math.Max(MeasureWrappedHeight(caption,captionWidth),MeasureWrappedHeight(value,valueWidth))+8;
            var style=right.RowStyles[i+1];
            float scale=DeviceDpi/96f;
            int minimum=(int)Math.Ceiling(40*scale);
            style.SizeType=SizeType.Absolute;
            style.Height=Math.Max(minimum,needed);
        }
    }
    static int MeasureWrappedHeight(Label label,int width)
    {
        if(string.IsNullOrEmpty(label.Text))return 0;
        using var graphics=label.CreateGraphics();
        var measured=graphics.MeasureString(label.Text,label.Font,new SizeF(Math.Max(1,width),1000),StringFormat.GenericDefault);
        return (int)Math.Ceiling(measured.Height)+label.Padding.Vertical;
    }
    protected override void OnLayout(LayoutEventArgs e)
    {
        base.OnLayout(e);
        FitFieldRows();
    }
    protected override void OnSizeChanged(EventArgs e)
    {
        base.OnSizeChanged(e);
        if(root==null)return;
        int width=Math.Max(200,Width-root.Padding.Horizontal);
        foreach(var label in new[]{notice,scope})label.MaximumSize=new Size(width,0);
        int detailWidth=Math.Max(160,(int)((Width-root.Padding.Horizontal-56)*.69));
        foreach(var label in new[]{batteryModel,manufacturer,detailTime})
        {
            var maximum=new Size(detailWidth,0);
            if(label.MaximumSize!=maximum)label.MaximumSize=maximum;
        }
    }
    protected override void Dispose(bool disposing){if(disposing)tips.Dispose();base.Dispose(disposing);}
}
