using System.Drawing.Drawing2D;
using System.Drawing.Text;

namespace BatteryDiagnostic;

internal sealed class PerformanceDashboard : UserControl
{
    readonly ComboBox modules=Selector(),gpus=Selector(),disks=Selector(),volumes=Selector();
    readonly LinkLabel cpuActivate=AccessLink("cpu"),diskAccess=AccessLink("diskAccess"),smartDetails=AccessLink("smartDetails");
    readonly ToolTip tips=new() {AutoPopDelay=20000,InitialDelay=450,ReshowDelay=250};
    readonly Queue<(DateTimeOffset Time,double? Usage)> history=[];
    PerformanceInventory? inventory;
    PerformanceLive? live;
    StorageSnapshot? storage;
    UiLanguage language=UiLanguage.French;
    bool updating;
    string moduleKey="",gpuKey="",diskKey="",volumeKey="",tipKey="";
    float viewScale=1,viewX,viewY;
    string T(string key)=>PerfText.Get(language,key);
    string Unknown=>T("unknown");
    string N(double value,string format="0.#")=>value.ToString(format,L.Culture(language));
    string Memory(ulong? bytes)=>bytes.HasValue?N(bytes.Value/1073741824d)+" "+T("gib"):Unknown;
    string DiskBytes(ulong? bytes)=>bytes.HasValue?N(bytes.Value/1000000000d)+" "+T("gb"):Unknown;
    string Percent(double? value)=>value.HasValue&&double.IsFinite(value.Value)?L.Percent(language,value.Value):Unknown;
    string Number(object? value)=>value==null?Unknown:Convert.ToString(value,L.Culture(language))??Unknown;
    StorageDisk? SelectedDisk=>storage?.Disks.ElementAtOrDefault(disks.SelectedIndex);
    StorageVolume? SelectedVolume=>SelectedDisk?.Volumes.ElementAtOrDefault(volumes.SelectedIndex);
    MemoryModule? SelectedModule=>inventory?.Memory.Modules.ElementAtOrDefault(modules.SelectedIndex);
    GpuInventory? SelectedGpu=>inventory?.Gpus.ElementAtOrDefault(gpus.SelectedIndex);
    internal bool HasLiveSample=>live!=null;
    internal int SampleCount=>history.Count;
    internal string CurrentDiskCondition=>Health(SelectedDisk);
    internal string CurrentDiskResource=>Resource(SelectedDisk);
    internal IReadOnlyList<ComboBox> Selectors=>[modules,gpus,disks,volumes];
    internal event EventHandler? CpuActivationRequested;
    internal event EventHandler? StorageAccessRequested;
    internal event EventHandler? StorageDetailsRequested;
    internal string? SelectedDiskIdentity=>SelectedDisk?.DeviceId;
    static LinkLabel AccessLink(string tag)=>new() {Tag=tag,TextAlign=ContentAlignment.MiddleRight,LinkColor=Theme.Accent,ActiveLinkColor=Theme.Text,VisitedLinkColor=Theme.Accent,BackColor=Theme.Card,AutoSize=false,TabStop=true,Font=new Font("Segoe UI",8.5f)};
    static ComboBox Selector()
    {
        var combo=new DarkSelector {DropDownStyle=ComboBoxStyle.DropDownList,FlatStyle=FlatStyle.Flat,DrawMode=DrawMode.OwnerDrawFixed,BackColor=Theme.Header,ForeColor=Theme.Text,Font=new Font("Segoe UI",9),IntegralHeight=true,DropDownHeight=250};
        combo.DrawItem+=(_,e)=>
        {
            using var bg=new SolidBrush((e.State&DrawItemState.Selected)!=0&&((e.State&DrawItemState.ComboBoxEdit)==0)?Theme.Border:Theme.Header);
            e.Graphics.FillRectangle(bg,e.Bounds);
            string value=e.Index>=0&&e.Index<combo.Items.Count?combo.Items[e.Index]?.ToString()??"":"";
            TextRenderer.DrawText(e.Graphics,value,combo.Font,e.Bounds,combo.Enabled?Theme.Text:Theme.Muted,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.LeftAndRightPadding);
        };
        return combo;
    }

    internal PerformanceDashboard()
    {
        DoubleBuffered=true;ResizeRedraw=true;BackColor=Theme.Background;AutoScroll=false;
        Controls.AddRange([modules,gpus,disks,volumes,cpuActivate,diskAccess,smartDetails]);
        cpuActivate.LinkClicked+=(_,_)=>CpuActivationRequested?.Invoke(this,EventArgs.Empty);
        diskAccess.LinkClicked+=(_,_)=>StorageAccessRequested?.Invoke(this,EventArgs.Empty);
        smartDetails.LinkClicked+=(_,_)=>StorageDetailsRequested?.Invoke(this,EventArgs.Empty);
        foreach(var c in new[]{modules,gpus,disks,volumes})c.SelectedIndexChanged+=(_,_)=>
        {
            if(updating)return;
            if(c==disks)UpdateVolumes();
            UpdateTips();Invalidate();
        };
    }
    internal void AddSample(PerformanceLive sample)
    {
        history.Enqueue((sample.Timestamp,sample.CpuUsagePercent));while(history.Count>60)history.Dequeue();
    }
    internal void SetData(PerformanceInventory? inv,PerformanceLive? current,StorageSnapshot? drives,UiLanguage lang)
    {
        bool changedLanguage=language!=lang;
        inventory=inv;live=current;storage=drives;language=lang;
        if(changedLanguage){tipKey="";tips.SetToolTip(this,null);}
        updating=true;
        try
        {
            Populate(modules,ref moduleKey,inv?.Memory.Modules.Select((m,i)=>(m.Slot??(T("module")+" "+(i+1)))+" · "+Memory(m.CapacityBytes)).ToArray()??[],inv?.Memory.Modules.Select((m,i)=>(m.Slot??i.ToString())+":"+m.PartNumber).ToArray()??[]);
            Populate(gpus,ref gpuKey,inv?.Gpus.Select(g=>g.Model??Unknown).ToArray()??[],inv?.Gpus.Select(g=>g.Id).ToArray()??[]);
            Populate(disks,ref diskKey,drives?.Disks.Select(d=>(d.Index.HasValue?d.Index+" · ":"")+(string.IsNullOrWhiteSpace(d.Model)?Unknown:d.Model)).ToArray()??[],drives?.Disks.Select(d=>d.DeviceId).ToArray()??[]);
            UpdateVolumes();
        }
        finally {updating=false;}
        modules.AccessibleName=T("module");gpus.AccessibleName=T("gpu");disks.AccessibleName=T("disk");volumes.AccessibleName=T("volume");
        cpuActivate.Text=T("cpuActivate");cpuActivate.AccessibleName=T("cpuActivate");
        cpuActivate.Visible=false;
        diskAccess.Text=T("diskAccess");diskAccess.AccessibleName=T("diskAccess");
        smartDetails.Text=T("smartDetails");smartDetails.AccessibleName=T("smartDetails");smartDetails.Visible=SelectedDisk!=null;
        diskAccess.Visible=!PerformanceCpuTemperature.IsAdministrator&&(drives?.Diagnostics.Concat(drives.Disks.SelectMany(d=>d.Diagnostics)).Any(d=>d.Contains("AccessDenied",StringComparison.Ordinal))??false);
        AccessibleName=T("heading");
        AccessibleDescription=T("cpu")+": "+(inv?.Cpu.Model??Unknown)+"; "+T("ram")+": "+Memory(current?.Memory.TotalBytes)+"; "+T("notHealthTest");
        UpdateTips();Invalidate();
    }
    void Populate(ComboBox combo,ref string key,string[] values,string[] identities)
    {
        string next=L.Code(language)+":"+string.Join("\n",values)+":"+string.Join("\n",identities);
        if(next==key)return;
        key=next;string? previous=(combo.Tag as string[])?.ElementAtOrDefault(combo.SelectedIndex);
        int selected=previous==null?0:Array.IndexOf(identities,previous);combo.Tag=identities;
        combo.BeginUpdate();
        try {combo.Items.Clear();combo.Items.AddRange(values.Length>0?values:[Unknown]);combo.SelectedIndex=Math.Clamp(selected,0,combo.Items.Count-1);combo.Enabled=values.Length>0;}
        finally {combo.EndUpdate();}
    }
    void UpdateVolumes()
    {
        var disk=SelectedDisk;
        Populate(volumes,ref volumeKey,disk?.Volumes.Select(v=>v.Name+" · "+(v.FileSystem??Unknown)+(v.SharedAcrossDisks?" *":"")).ToArray()??[],disk?.Volumes.Select(v=>disk.DeviceId+":"+v.Name).ToArray()??[]);
    }
    bool StorageFresh=>storage!=null&&(DateTimeOffset.Now-storage.Timestamp).Duration().TotalSeconds<=45;
    string Health(StorageDisk? disk)
    {
        if(disk==null)return Unknown;
        if(!StorageFresh)return T("storageStale");
        return T(DiskAssessmentEngine.Evaluate(disk).StateKey);
    }
    string Resource(StorageDisk? disk)
    {
        if(disk is null)return Unknown;
        if(!StorageFresh)return T("storageStale");
        var assessment=DiskAssessmentEngine.Evaluate(disk);
        if(assessment.Remaining is not {} value)return Unknown;
        return L.Percent(language,value)+" · "+T(assessment.Resource switch {DiskResourceGrade.Normal=>"lifeNormal",DiskResourceGrade.Low=>"lifeLow",_=>"lifeExhausted"});
    }
    string DiskExplanation()
    {
        var d=StorageFresh?SelectedDisk:null;
        if(d==null)return T("health")+": "+Health(SelectedDisk)+Environment.NewLine+T("healthTip");
        string source=T(d.HealthSource switch {"WindowsStorage"=>"sourceStorage","NvmeHealthLog"=>"sourceNvme","FailurePrediction"=>"sourcePrediction","AtaSmartThresholds"=>"sourceAta","AtaSmartSectors"=>"sourceSectors",_=>"unknown"});
        string summary=PerfText.F(language,"diskSummary",d.TemperatureC is {} temperature?N(temperature)+" °C":Unknown,Number(d.PowerOnCount),Number(d.PowerOnHours));
        var lines=new List<string> {d.Model,T("health")+": "+Health(d),summary,T("basis")+": "+source};
        if(d.NvmeAvailableSparePercent.HasValue)lines.Add(PerfText.F(language,"nvmeSpare",Number(d.NvmeAvailableSparePercent),Number(d.NvmeSpareThresholdPercent)));
        if(d.NvmeCriticalWarning.HasValue)lines.Add(T("nvmeFlags")+": 0x"+d.NvmeCriticalWarning.Value.ToString("X2"));
        var sensorLines=d.NvmeSensorTemperaturesC.Select((value,i)=>value.HasValue?"#"+(i+1)+": "+N(value.Value)+" °C":null).Where(s=>s!=null);
        if(sensorLines.Any())lines.Add(T("temperature")+": "+string.Join("; ",sensorLines));
        if(d.RemainingLifePercent.HasValue)lines.Add(T("lifeTip"));
        if(d.RemainingLifeSource!="None")lines.Add(T("resourceSource")+": "+d.RemainingLifeSource);
        if(d.TemperatureSource!="None")lines.Add(T("temperature")+": "+d.TemperatureSource);
        if(d.PowerOnCount is {} cycles)lines.Add(T("powerCycles")+": "+N(cycles));
        if(d.HostReadsBytes is {} readBytes)lines.Add(T("hostReads")+": "+N(Math.Floor(readBytes/1073741824d))+" GiB");
        if(d.HostWritesBytes is {} writtenBytes)lines.Add(T("hostWrites")+": "+N(Math.Floor(writtenBytes/1073741824d))+" GiB");
        if(d.FailurePredicted==false)lines.Add(T("noPrediction"));
        if(d.HealthCode=="NoFailurePredicted")lines.Add(T("limitedSmart"));
        if(d.SmartAttributes.Count>0)lines.Add(PerfText.F(language,"smartCount",d.SmartAttributes.Count));
        if(d.Diagnostics.Any(code=>code.Contains("AccessDenied",StringComparison.Ordinal)))lines.Add(T("accessLimited"));
        if(d.MediaType=="NonRotating")lines.Add(T("seekBasis"));
        lines.Add(T("healthTip"));return string.Join(Environment.NewLine,lines);
    }
    void UpdateTips()
    {
        tips.SetToolTip(cpuActivate,CpuExplanation());
        tips.SetToolTip(diskAccess,T("diskElevate"));
        tips.SetToolTip(modules,string.Join(Environment.NewLine,new[]{SelectedModule?.Slot,MemoryManufacturer.Display(SelectedModule?.Manufacturer),SelectedModule?.Manufacturer,SelectedModule?.PartNumber,T("ramTip")}.Where(s=>!string.IsNullOrEmpty(s))));
        tips.SetToolTip(gpus,(SelectedGpu?.Model??Unknown)+Environment.NewLine+T("gpuTip")+Environment.NewLine+T("gpuLoadBasis"));
        tips.SetToolTip(disks,DiskExplanation());
        tips.SetToolTip(volumes,SelectedVolume?.SharedAcrossDisks==true?T("sharedVolume")+Environment.NewLine+T("diskTip"):T("diskTip"));
    }
    string CpuExplanation()
    {
        if(live?.CpuTemperatureC is {} temp)
        {
            string source=live.Notes.FirstOrDefault(n=>n.StartsWith("CPU temperature source: ",StringComparison.Ordinal))
                ??"CPU temperature source: Unavailable";
            return T("temperature")+": "+N(temp)+" °C"+Environment.NewLine+source;
        }
        string key=PerformanceCpuTemperature.ReadCached().State switch
        {
            CpuTemperatureState.Disabled=>"cpuDisabled",CpuTemperatureState.Starting=>"cpuStarting",
            CpuTemperatureState.AdministratorRequired=>"cpuElevate",CpuTemperatureState.DriverNotInstalled=>"cpuDriverMissing",
            CpuTemperatureState.DriverRejected=>"cpuDriverRejected",CpuTemperatureState.UnsupportedProcessor=>"cpuUnsupported",
            CpuTemperatureState.Ready=>"cpuReady",_=>"cpuUnavailable"
        };
        return T("cpuTip")+Environment.NewLine+T(key);
    }
    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);float x=(e.X-viewX)/viewScale,y=(e.Y-viewY)/viewScale;
        string next=y is >=68 and <=296?(x<500?"cpuTip":"ramTip"):y is >=306 and <=500?(x<500?"gpuTip":"diskTip"):"";
        if(next!=tipKey){tipKey=next;tips.SetToolTip(this,next=="diskTip"?DiskExplanation():next=="cpuTip"?CpuExplanation():next.Length>0?T(next):null);}
    }
    protected override void OnResize(EventArgs e){base.OnResize(e);PlaceSelectors();}
    void PlaceSelectors()
    {
        if(modules==null||Width<=0||Height<=0)return;
        viewScale=Math.Max(.1f,Math.Min(Width/1000f,Height/538f));viewX=(Width-1000*viewScale)/2;viewY=(Height-538*viewScale)/2;
        Place(modules,520,187,446);Place(gpus,32,343,449);Place(disks,519,343,449);Place(volumes,519,425,449);
        cpuActivate.SetBounds((int)(viewX+335*viewScale),(int)(viewY+80*viewScale),(int)(146*viewScale),(int)(22*viewScale));
        diskAccess.SetBounds((int)(viewX+815*viewScale),(int)(viewY+318*viewScale),(int)(152*viewScale),(int)(22*viewScale));
        smartDetails.SetBounds((int)(viewX+714*viewScale),(int)(viewY+318*viewScale),(int)(90*viewScale),(int)(22*viewScale));
        float size=Math.Max(7.5f,8.5f*viewScale*96/DeviceDpi);
        if(Math.Abs(cpuActivate.Font.Size-size)>.1){var old=cpuActivate.Font;cpuActivate.Font=new Font("Segoe UI",size);old.Dispose();}
        if(Math.Abs(diskAccess.Font.Size-size)>.1){var old=diskAccess.Font;diskAccess.Font=new Font("Segoe UI",size);old.Dispose();}
        if(Math.Abs(smartDetails.Font.Size-size)>.1){var old=smartDetails.Font;smartDetails.Font=new Font("Segoe UI",size);old.Dispose();}
    }
    void Place(ComboBox combo,int x,int y,int width)
    {
        float fontSize=Math.Max(7.5f,9*viewScale*96/DeviceDpi);
        if(Math.Abs(combo.Font.Size-fontSize)>.1){var old=combo.Font;combo.Font=new Font("Segoe UI",fontSize);old.Dispose();}
        combo.ItemHeight=Math.Max(14,(int)(19*viewScale));
        combo.SetBounds((int)(viewX+x*viewScale),(int)(viewY+y*viewScale),(int)(width*viewScale),(int)(24*viewScale));
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);var g=e.Graphics;g.Clear(Theme.Background);g.SmoothingMode=SmoothingMode.AntiAlias;g.TextRenderingHint=TextRenderingHint.ClearTypeGridFit;
        g.TranslateTransform(viewX,viewY);g.ScaleTransform(viewScale,viewScale);
        DrawText(g,T("heading"),18,10,960,28,20,true);DrawText(g,T("subtitle"),18,42,960,18,10,false,Theme.Muted);
        Card(g,18,68,477,228,T("cpu"));Card(g,505,68,477,228,T("ram"));Card(g,18,306,477,194,T("gpu"));Card(g,505,306,477,194,T("disk"));
        DrawCpu(g);DrawMemory(g);DrawGpu(g);DrawStorage(g);
        DrawText(g,T("notHealthTest"),18,513,964,21,9,false,Theme.Muted);
    }
    void Card(Graphics g,float x,float y,float w,float h,string name)
    {
        using var path=Theme.Round(new RectangleF(x,y,w,h),8);using var bg=new SolidBrush(Theme.Card);using var border=new Pen(Theme.Border);
        g.FillPath(bg,path);g.DrawPath(border,path);DrawText(g,name,x+14,y+12,w-28,21,12,true);
    }
    static void DrawText(Graphics g,string text,float x,float y,float w,float h,float size=10,bool bold=false,Color? color=null)
    {
        using var font=new Font("Segoe UI",size, bold?FontStyle.Bold:FontStyle.Regular,GraphicsUnit.Pixel);
        using var brush=new SolidBrush(color??Theme.Text);using var format=new StringFormat {Trimming=StringTrimming.EllipsisCharacter,FormatFlags=StringFormatFlags.LineLimit};
        g.DrawString(text,font,brush,new RectangleF(x,y,w,h),format);
    }
    void Stat(Graphics g,string label,string value,float x,float y,float w=86,float valueSize=13,Color? valueColor=null)
    {DrawText(g,label,x,y,w,28,10,false,Theme.Muted);DrawText(g,value,x,y+29,w,34,valueSize,true,valueColor);}
    void DrawCpu(Graphics g)
    {
        DrawText(g,inventory?.Cpu.Model??Unknown,32,105,449,34,12,true);
        string? source=live?.Notes.FirstOrDefault(n=>n.StartsWith("CPU temperature source: ",StringComparison.Ordinal));
        if(live?.CpuTemperatureC.HasValue==true && source is not null)
            DrawText(g,source[24..],321,83,160,17,10,false,Theme.Accent);
        var rect=new RectangleF(32,151,252,127);using var pen=new Pen(Theme.Border);g.DrawRectangle(pen,rect);
        for(int row=1;row<4;row++)g.DrawLine(pen,rect.Left,rect.Top+row*rect.Height/4,rect.Right,rect.Top+row*rect.Height/4);
        var samples=history.ToArray();using var line=new Pen(Theme.Accent,1.8f);
        bool hasPoint=false;
        for(int i=1;live!=null&&i<samples.Length;i++)
        {
            if(samples[i-1].Usage is not { } a||samples[i].Usage is not { } b||(samples[i].Time-samples[i-1].Time).TotalSeconds>6)continue;
            float x1=rect.Right-(samples.Length-i)*rect.Width/59,x2=x1+rect.Width/59;
            g.DrawLine(line,x1,rect.Bottom-(float)Math.Clamp(a/100,0,1)*rect.Height,x2,rect.Bottom-(float)Math.Clamp(b/100,0,1)*rect.Height);hasPoint=true;
        }
        if(!hasPoint)DrawText(g,T("noSamples"),43,201,230,38,10,false,Theme.Muted);
        Stat(g,T("usage"),Percent(live?.CpuUsagePercent),298,151);
        Stat(g,T("temperature"),live?.CpuTemperatureC is {} temp?N(temp)+" °C":Unknown,391,151,86,
            live?.CpuTemperatureC.HasValue==true?17:12,live?.CpuTemperatureC.HasValue==true?Theme.Accent:null);
        Stat(g,T("frequency"),live?.CpuFrequencyMHz is {} freq?N(freq/1000,"0.00")+" GHz":Unknown,298,217);
        Stat(g,T("cores"),Number(inventory?.Cpu.PhysicalCores)+" / "+Number(inventory?.Cpu.LogicalProcessors),391,217);
    }
    void DrawMemory(Graphics g)
    {
        DrawText(g,T("used")+": "+Memory(live?.Memory.UsedBytes),520,108,215,32,14,true);
        DrawText(g,T("available")+": "+Memory(live?.Memory.AvailableBytes),744,108,222,32,14,true);
        using var bg=new SolidBrush(Theme.Border);g.FillRectangle(bg,520,149,446,6);
        if(live?.Memory.TotalBytes is >0 && live.Memory.UsedBytes.HasValue)
        {using var fill=new SolidBrush(Theme.Accent);g.FillRectangle(fill,520,149,(float)Math.Clamp(live.Memory.UsedBytes.Value/(double)live.Memory.TotalBytes.Value,0,1)*446,6);}
        DrawText(g,T("modules"),520,164,265,19,10,false,Theme.Muted);
        DrawText(g,(inventory?.Memory.Modules.Count is >0?inventory.Memory.Modules.Count.ToString(L.Culture(language)):Unknown)+" / "+Number(inventory?.Memory.TotalSlots),754,164,212,19,11,true);
        var m=SelectedModule;
        DrawText(g,T("speed")+": "+(m?.ConfiguredSpeedMTs is {} speed?N(speed,"0")+" "+T("mt"):m?.ConfiguredClockMHz is {} clock?N(clock,"0")+" "+T("mhz"):Unknown),520,220,446,24,12,true);
        DrawText(g,T("manufacturer")+": "+(MemoryManufacturer.Display(m?.Manufacturer)??Unknown),520,248,446,24,12,true);
    }
    void DrawGpu(Graphics g)
    {
        var gpu=SelectedGpu;var status=live?.Gpus.FirstOrDefault(v=>v.Id==gpu?.Id);
        string kind=T(gpu?.Kind switch {GpuKind.Integrated=>"integrated",GpuKind.Dedicated=>"dedicated",GpuKind.Software=>"software",_=>"typeUnknown"});
        DrawText(g,kind,32,374,210,21,11,false,Theme.Muted);
        DrawText(g,T("frequency")+": "+(status?.FrequencyMHz is {} f?N(f)+" "+T("mhz"):Unknown),254,374,227,21,11,false,Theme.Muted);
        DrawText(g,T("videoMemory"),32,397,205,20,10,false,Theme.Muted);
        DrawText(g,T("temperature")+": "+(status?.TemperatureC is {} temperature?N(temperature)+" °C":Unknown),250,397,231,20,10,false,Theme.Muted);
        ulong? free=gpu?.DedicatedMemoryBytes is {} total&&status?.DedicatedUsedBytes is {} used&&used<=total?total-used:null;
        MemoryCell(g,T("total"),Memory(gpu?.DedicatedMemoryBytes),32,415);
        MemoryCell(g,T("used"),Memory(status?.DedicatedUsedBytes),182,415);
        MemoryCell(g,T("free"),Memory(free),332,415);
        DrawText(g,T("sharedMemory")+": "+Memory(status?.SharedUsedBytes),32,457,449,21,11);
        DrawText(g,T("usage")+": "+Percent(status?.UsagePercent),32,480,449,18,10,false,Theme.Muted);
    }
    void DrawStorage(Graphics g)
    {
        var d=SelectedDisk;var v=StorageFresh?SelectedVolume:null;var freshDisk=StorageFresh?d:null;
        string type=d==null?Unknown:(d.MediaType=="Unknown"?T("typeUnknown"):d.MediaType=="NonRotating"?T("nonRotating"):d.MediaType)+" · "+(d.BusType??Unknown)+" · "+DiskBytes(d.TotalBytes);
        DrawText(g,type,519,371,449,17,10,false,Theme.Muted);
        string health=Health(d);Color color=freshDisk!=null?DiskAssessmentEngine.Evaluate(freshDisk).Color:Theme.Muted;
        DrawText(g,T("health")+": "+health,519,388,449,20,12,true,color);
        DrawText(g,PerfText.F(language,"diskStartsHours",freshDisk?.PowerOnCount?.ToString(L.Culture(language))??"—",freshDisk?.PowerOnHours?.ToString(L.Culture(language))??"—"),519,410,449,20,11,true);
        MemoryCell(g,T("total"),DiskBytes(v?.TotalBytes),519,450);MemoryCell(g,T("usedSpace"),DiskBytes(v?.UsedBytes),669,450);MemoryCell(g,T("free"),DiskBytes(v?.FreeBytes),819,450);
        DrawText(g,PerfText.F(language,"diskTempLine",freshDisk?.TemperatureC is {} temp?N(temp)+" °C":"—"),519,482,449,17,11,true,Theme.Text);
    }
    static void MemoryCell(Graphics g,string caption,string value,float x,float y)
    {DrawText(g,caption,x,y,145,15,10,false,Theme.Muted);DrawText(g,value,x,y+15,145,18,12,true);}
    protected override void Dispose(bool disposing){if(disposing)tips.Dispose();base.Dispose(disposing);}
}

internal sealed class DarkSelector : ComboBox
{
    protected override void WndProc(ref Message message)
    {
        base.WndProc(ref message);
        if(message.Msg is not (0x000F or 0x0085 or 0x0317 or 0x0318)||IsDisposed||!IsHandleCreated||Width<12||Height<10)return;
        // Native ComboBox paints the drop arrow using the light Windows theme.
        // Cover only its chrome; retain native keyboard/list/accessibility behavior.
        using var g=message.Msg is 0x0317 or 0x0318&&message.WParam!=IntPtr.Zero?Graphics.FromHdc(message.WParam):Graphics.FromHwnd(Handle);int arrow=Math.Max(16,(int)(18*DeviceDpi/96f));
        using var bg=new SolidBrush(Theme.Header);g.FillRectangle(bg,Width-arrow,0,arrow,Height);
        using var border=new Pen(Theme.Border,2);g.DrawRectangle(border,1,1,Width-2,Height-2);
        using var pen=new Pen(Enabled?Theme.Text:Theme.Muted,1.3f);float x=Width-arrow/2f,y=Height/2f;
        g.DrawLine(pen,x-3,y-1,x,y+2);g.DrawLine(pen,x,y+2,x+3,y-1);
    }
}

